---
name: Orval Zod v4 import fix
description: Orval generates zod.int() (Zod v4 syntax) but the workspace catalog pins zod@3 — the generated file imports from 'zod' which resolves to v3 and breaks typecheck.
---

## The rule
After adding `afterAllFilesWrite` to the `zod` output in `lib/api-spec/orval.config.ts`, use a targeted sed command on the specific generated file only — NOT on the whole output dir (which includes a subdirectory and causes `sed` exit code 4).

**Why:** The workspace `pnpm-workspace.yaml` catalog pins `zod: ^3.25.76`. Orval v8.23+ emits `zod.int()` which is Zod v4 API. The generated file imports `from 'zod'` which resolves to v3 and typecheck fails with `Property 'int' does not exist`.

**How to apply:** In `lib/api-spec/orval.config.ts`, the `zod` output block has:
```ts
hooks: {
  afterAllFilesWrite:
    `sed -i "s|from 'zod'|from 'zod/v4'|g" ${apiZodSrc}/generated/api.ts`,
},
```
This patches only `generated/api.ts`. The sed command will also be invoked on other files by orval (including the `types` directory) and will log exit code 4 for the directory, but this is harmless — only `api.ts` contains the `from 'zod'` import.
