---
name: Express route ordering
description: Static sub-routes must be registered before param routes to avoid being swallowed.
---

## The rule
In Express, route handlers are matched in registration order. Register static paths like `/builds/stats`, `/builds/categories`, and `/builds/my` BEFORE the param route `/builds/:id`.

**Why:** Express will match `/builds/stats` against `/builds/:id` (with `id = "stats"`) if the param route is registered first, then fail to find a record with that id and return 404.

**How to apply:** In `artifacts/api-server/src/routes/builds.ts`, always put all fixed-path handlers before `router.get("/builds/:id", ...)`.
