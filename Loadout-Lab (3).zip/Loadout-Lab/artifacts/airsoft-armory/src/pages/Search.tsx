import { useListBuilds, useListCategories } from "@workspace/api-client-react";
import { BuildCard } from "@/components/BuildCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, Filter, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

export default function Search() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>(undefined);
  const [minPrice, setMinPrice] = useState<string>("");
  const [maxPrice, setMaxPrice] = useState<string>("");

  const { data: categories } = useListCategories();
  
  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 500);
    return () => clearTimeout(timer);
  }, [search]);

  const queryParams: any = {};
  if (debouncedSearch) queryParams.search = debouncedSearch;
  if (category) queryParams.category = category;
  if (minPrice) queryParams.minPrice = Number(minPrice);
  if (maxPrice) queryParams.maxPrice = Number(maxPrice);

  const { data, isLoading } = useListBuilds(queryParams);

  const clearFilters = () => {
    setSearch("");
    setDebouncedSearch("");
    setCategory(undefined);
    setMinPrice("");
    setMaxPrice("");
  };

  return (
    <div className="w-full flex flex-col md:flex-row gap-8 items-start">
      {/* Filters Sidebar */}
      <div className="w-full md:w-64 shrink-0 flex flex-col gap-6 sticky top-24">
        <div className="flex items-center gap-2 border-b border-border/50 pb-2">
          <Filter className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-mono uppercase tracking-widest font-bold">Parameters</h2>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Query</label>
            <div className="relative">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Designation..." 
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                data-testid="input-search"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Category</label>
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={!category ? "default" : "outline"} 
                size="sm" 
                onClick={() => setCategory(undefined)}
                className="text-xs font-mono h-7"
              >
                ALL
              </Button>
              {categories?.map(c => (
                <Button 
                  key={c}
                  variant={category === c ? "default" : "outline"} 
                  size="sm" 
                  onClick={() => setCategory(c)}
                  className="text-xs font-mono h-7"
                >
                  {c}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Cost Range (USD)</label>
            <div className="flex items-center gap-2">
              <Input 
                type="number" 
                placeholder="Min" 
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="w-full"
              />
              <span className="text-muted-foreground">-</span>
              <Input 
                type="number" 
                placeholder="Max" 
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-full"
              />
            </div>
          </div>

          <Button 
            variant="ghost" 
            className="w-full text-xs font-mono uppercase text-muted-foreground hover:text-foreground mt-4 gap-2"
            onClick={clearFilters}
          >
            <X className="w-3 h-3" />
            Reset Parameters
          </Button>
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 w-full flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="text-sm font-mono text-muted-foreground">
            {isLoading ? "Querying database..." : `Found ${data?.total || 0} matching records`}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-64 w-full" />
            ))}
          </div>
        ) : data?.builds.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border/50 bg-secondary/10 rounded-sm">
            <SearchIcon className="w-10 h-10 text-muted-foreground mb-4 opacity-50" />
            <h2 className="text-lg font-mono text-foreground mb-2">No matching records</h2>
            <p className="text-sm text-muted-foreground max-w-md">
              Try adjusting your search parameters or removing filters.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {data?.builds.map((build, i) => (
              <div 
                key={build.id} 
                className="animate-in fade-in slide-in-from-bottom-4 fill-mode-both"
                style={{ animationDelay: `${i * 50}ms`, animationDuration: '500ms' }}
              >
                <BuildCard build={build} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
