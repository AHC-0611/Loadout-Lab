import { useState } from "react";
import { useListBuilds, getListBuildsQueryKey } from "@workspace/api-client-react";
import { useUser } from "@clerk/react";
import { BuildCard } from "@/components/BuildCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Terminal, Globe, Users, UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

type FeedTab = "global" | "following";

export default function Feed() {
  const { isSignedIn } = useUser();
  const [tab, setTab] = useState<FeedTab>("global");

  const globalParams = { limit: 50 };
  const followingParams = { limit: 50, feed: "following" };

  const { data: globalData, isLoading: globalLoading } = useListBuilds(
    globalParams,
    { query: { enabled: tab === "global", queryKey: getListBuildsQueryKey(globalParams) } },
  );

  const { data: followingData, isLoading: followingLoading } = useListBuilds(
    followingParams,
    { query: { enabled: tab === "following" && !!isSignedIn, queryKey: getListBuildsQueryKey(followingParams) } },
  );

  const isLoading = tab === "global" ? globalLoading : followingLoading;
  const data = tab === "global" ? globalData : followingData;
  const builds = data?.builds ?? [];

  return (
    <div className="w-full flex flex-col gap-6">
      <div className="flex flex-col gap-3 border-b border-border/50 pb-4">
        <div className="flex items-center gap-3">
          <Terminal className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold font-sans uppercase tracking-tight">Build Feed</h1>
        </div>

        {/* Tab selector */}
        <div className="flex gap-1">
          <button
            onClick={() => setTab("global")}
            className={cn(
              "flex items-center gap-2 px-4 py-2 text-sm font-mono uppercase tracking-wider rounded-sm transition-colors",
              tab === "global"
                ? "bg-secondary text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
            )}
          >
            <Globe className="w-4 h-4" />
            Global
          </button>

          {isSignedIn ? (
            <button
              onClick={() => setTab("following")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 text-sm font-mono uppercase tracking-wider rounded-sm transition-colors",
                tab === "following"
                  ? "bg-secondary text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
              )}
            >
              <Users className="w-4 h-4" />
              Following
            </button>
          ) : (
            <Link
              href="/sign-in"
              className="flex items-center gap-2 px-4 py-2 text-sm font-mono uppercase tracking-wider rounded-sm text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
            >
              <Users className="w-4 h-4" />
              Following
            </Link>
          )}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      ) : tab === "following" && builds.length === 0 ? (
        <FollowingEmptyState />
      ) : builds.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border/50 bg-secondary/10 rounded-sm">
          <Terminal className="w-10 h-10 text-muted-foreground mb-4 opacity-50" />
          <h2 className="text-lg font-mono text-foreground mb-2">No builds found in database</h2>
          <p className="text-sm text-muted-foreground max-w-md">
            The registry is currently empty. Be the first to document a platform.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {builds.map((build, i) => (
            <div
              key={build.id}
              className="animate-in fade-in slide-in-from-bottom-4 fill-mode-both"
              style={{ animationDelay: `${i * 50}ms`, animationDuration: "500ms" }}
            >
              <BuildCard build={build} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FollowingEmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-border/50 bg-secondary/10 rounded-sm gap-4">
      <UserPlus className="w-10 h-10 text-muted-foreground opacity-50" />
      <div>
        <h2 className="text-lg font-mono text-foreground mb-2">No builds from your network yet</h2>
        <p className="text-sm text-muted-foreground max-w-md">
          Follow builders or add friends to see their builds here.
        </p>
      </div>
      <Link href="/search">
        <button className="px-4 py-2 text-sm font-mono uppercase tracking-wider rounded-sm border border-primary/50 text-primary hover:bg-primary/10 transition-colors">
          Browse Builders
        </button>
      </Link>
    </div>
  );
}
