import { useEffect, useRef, useState } from "react";
import { useUser } from "@clerk/react";
import { Link, Redirect } from "wouter";
import {
  Camera, Save, Loader2, CheckCircle2, XCircle, AlertTriangle,
  ExternalLink, User, Link as LinkIcon, Eye, Crosshair, Star, Heart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useProfile, avatarUrl } from "@/context/ProfileContext";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;

type CheckState = "idle" | "checking" | "available" | "taken" | "invalid" | "same";

// ─── Section wrapper ──────────────────────────────────────────────────────────

function Section({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ElementType;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-card border border-border rounded-sm p-6 space-y-5">
      <div className="flex items-center gap-3 border-b border-border/50 pb-3">
        <Icon className="w-4 h-4 text-primary" />
        <div>
          <h2 className="text-sm font-mono uppercase tracking-widest font-bold">{title}</h2>
          {description && <p className="text-xs text-muted-foreground font-mono mt-0.5">{description}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function ProfileSettings() {
  const { user, isLoaded } = useUser();
  const { profile, isLoading: profileLoading, hasProfile, refetchProfile } = useProfile();

  // Profile info form
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [instagramUrl, setInstagramUrl] = useState("");
  const [xUrl, setXUrl] = useState("");
  const [facebookUrl, setFacebookUrl] = useState("");
  const [tiktokUrl, setTiktokUrl] = useState("");
  const [showFavoritesPublic, setShowFavoritesPublic] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [avatarPath, setAvatarPath] = useState<string | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);

  // Username change
  const [usernameInput, setUsernameInput] = useState("");
  const [checkState, setCheckState] = useState<CheckState>("idle");
  const [changingUsername, setChangingUsername] = useState(false);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Avatar upload — uses a user-scoped presigned URL so the objectPath is
  // validated for ownership on the backend (IDOR protection).
  // We bypass useUpload here because it hardcodes the request-url endpoint.
  const [isUploading, setIsUploading] = useState(false);

  const uploadAvatar = async (file: File) => {
    setIsUploading(true);
    try {
      // Step 1: get user-scoped presigned URL from our profile endpoint
      // Send the file's content type so the server can validate it's an image.
      const urlRes = await fetch(`${BASE}/api/profiles/me/avatar-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contentType: file.type || "image/jpeg" }),
      });
      if (!urlRes.ok) throw new Error("Failed to get avatar upload URL");
      const { uploadURL, objectPath } = await urlRes.json();

      // Step 2: PUT the file directly to GCS
      const putRes = await fetch(uploadURL, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type || "application/octet-stream" },
      });
      if (!putRes.ok) throw new Error("Upload to storage failed");

      setAvatarPath(objectPath);
      setAvatarPreview(`${BASE}/api/storage${objectPath}`);
    } catch {
      // silently log; user will see upload button re-enable
    } finally {
      setIsUploading(false);
    }
  };

  // Populate form from profile
  useEffect(() => {
    if (!profile) return;
    setDisplayName(profile.displayName ?? "");
    setBio(profile.bio ?? "");
    setYoutubeUrl(profile.youtubeUrl ?? "");
    setInstagramUrl(profile.instagramUrl ?? "");
    setXUrl(profile.xUrl ?? "");
    setFacebookUrl(profile.facebookUrl ?? "");
    setTiktokUrl(profile.tiktokUrl ?? "");
    setShowFavoritesPublic(profile.showFavoritesPublic);
    setAvatarPath(profile.avatarPath ?? null);
    if (profile.avatarPath) {
      setAvatarPreview(avatarUrl(profile.avatarPath));
    }
  }, [profile?.userId]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!isLoaded || profileLoading) {
    return (
      <div className="w-full max-w-2xl mx-auto space-y-6">
        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-48" />)}
      </div>
    );
  }
  if (!user) return <Redirect to="/sign-in" />;
  if (!hasProfile) return <Redirect to="/setup/username" />;

  const saveProfile = async () => {
    setSavingProfile(true);
    setProfileSaved(false);
    try {
      const res = await fetch(`${BASE}/api/profiles/me`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName: displayName || null,
          bio: bio || null,
          youtubeUrl: youtubeUrl || null,
          instagramUrl: instagramUrl || null,
          xUrl: xUrl || null,
          facebookUrl: facebookUrl || null,
          tiktokUrl: tiktokUrl || null,
          showFavoritesPublic,
          avatarPath: avatarPath,
        }),
      });
      if (res.ok) {
        await refetchProfile();
        setProfileSaved(true);
        setTimeout(() => setProfileSaved(false), 3000);
      }
    } finally {
      setSavingProfile(false);
    }
  };

  const handleUsernameInput = (value: string) => {
    setUsernameInput(value);
    setUsernameError(null);
    if (timerRef.current) clearTimeout(timerRef.current);

    if (!value) { setCheckState("idle"); return; }
    if (value.toLowerCase() === profile!.username.toLowerCase()) {
      setCheckState("same"); return;
    }
    if (!USERNAME_RE.test(value)) { setCheckState("invalid"); return; }

    setCheckState("checking");
    timerRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`${BASE}/api/profiles/check-username?username=${encodeURIComponent(value)}`);
        const data = await res.json();
        setCheckState(data.available ? "available" : "taken");
      } catch { setCheckState("idle"); }
    }, 500);
  };

  const changeUsername = async () => {
    if (checkState !== "available" || changingUsername) return;
    setChangingUsername(true);
    setUsernameError(null);
    try {
      const res = await fetch(`${BASE}/api/profiles/me/username`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: usernameInput }),
      });
      if (res.ok) {
        await refetchProfile();
        setUsernameInput("");
        setCheckState("idle");
      } else {
        const data = await res.json();
        setUsernameError(data.error ?? "Failed to change callsign");
        setCheckState("taken");
      }
    } finally {
      setChangingUsername(false);
    }
  };

  const usernameStatusIcon = () => {
    if (checkState === "checking") return <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />;
    if (checkState === "available") return <CheckCircle2 className="w-4 h-4 text-green-500" />;
    if (checkState === "taken") return <XCircle className="w-4 h-4 text-destructive" />;
    if (checkState === "invalid" && usernameInput) return <XCircle className="w-4 h-4 text-destructive" />;
    return null;
  };

  const usernameStatusText = () => {
    if (checkState === "same") return <span className="text-muted-foreground">That's your current callsign</span>;
    if (checkState === "available") return <span className="text-green-500">Available</span>;
    if (checkState === "taken") return <span className="text-destructive">{usernameError ?? "Callsign taken"}</span>;
    if (checkState === "invalid" && usernameInput) return <span className="text-destructive">3–30 chars, letters/numbers/underscores only</span>;
    return null;
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col gap-6 pb-16">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <div className="flex items-center gap-3">
          <Crosshair className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold uppercase tracking-tight">Profile Settings</h1>
        </div>
        {profile && (
          <Link href={`/u/${profile.slug}`}>
            <Button variant="ghost" size="sm" className="font-mono text-xs gap-2 text-muted-foreground">
              <ExternalLink className="w-3.5 h-3.5" /> View Profile
            </Button>
          </Link>
        )}
      </div>

      {/* Quick links to related settings pages */}
      <div className="flex flex-wrap gap-2 -mt-2">
        <Link href="/settings/ratings">
          <Button variant="outline" size="sm" className="font-mono text-xs gap-2 border-yellow-500/30 text-yellow-400 hover:border-yellow-500/60">
            <Star className="w-3.5 h-3.5" /> My Ratings
          </Button>
        </Link>
        <Link href="/settings/favorites">
          <Button variant="outline" size="sm" className="font-mono text-xs gap-2 border-red-500/30 text-red-400 hover:border-red-500/60">
            <Heart className="w-3.5 h-3.5" /> Saved Builds
          </Button>
        </Link>
      </div>

      {/* Avatar + Identity */}
      <Section icon={User} title="Operator Identity" description="How you appear across the Armory">
        {/* Avatar */}
        <div className="flex items-start gap-4">
          <div className="w-20 h-20 rounded-full border-2 border-border bg-secondary flex items-center justify-center overflow-hidden shrink-0">
            {avatarPreview
              ? <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" onError={() => setAvatarPreview(null)} />
              : <span className="text-2xl font-bold text-primary uppercase">{profile?.username[0] ?? "?"}</span>
            }
          </div>
          <div className="space-y-2 flex-1">
            <label className={cn(
              "flex items-center gap-2 cursor-pointer px-4 py-2 rounded-sm border border-border text-xs font-mono uppercase tracking-widest w-fit transition-colors",
              isUploading ? "opacity-50 cursor-not-allowed" : "hover:border-primary/50 hover:text-primary hover:bg-primary/5"
            )}>
              {isUploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
              {isUploading ? "Uploading..." : avatarPreview ? "Replace Photo" : "Upload Photo"}
              <input type="file" accept="image/*" className="hidden" disabled={isUploading}
                onChange={async (e) => { const f = e.target.files?.[0]; if (f) await uploadAvatar(f); e.target.value = ""; }} />
            </label>
            {avatarPreview && (
              <button type="button" className="text-xs text-muted-foreground hover:text-destructive font-mono"
                onClick={() => { setAvatarPath(null); setAvatarPreview(null); }}>
                Remove photo
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Display Name</label>
            <Input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Your name (or leave blank to show username)" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Username</label>
            <Input value={`@${profile?.username ?? ""}`} disabled className="font-mono text-muted-foreground" />
            <p className="text-[10px] text-muted-foreground font-mono">Change in the Callsign section below</p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-mono text-muted-foreground uppercase">Bio</label>
          <Textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Tell operators about your play style, favorite guns, and experience..." className="min-h-[80px]" maxLength={300} />
          <p className="text-[10px] text-muted-foreground font-mono text-right">{bio.length}/300</p>
        </div>

        {/* Privacy */}
        <label className="flex items-center gap-3 cursor-pointer p-3 rounded-sm border border-border hover:bg-secondary/20 transition-colors">
          <input type="checkbox" checked={showFavoritesPublic} onChange={e => setShowFavoritesPublic(e.target.checked)}
            className="w-4 h-4 accent-primary" />
          <div>
            <p className="text-sm font-medium">Show favorite builds on public profile</p>
            <p className="text-xs text-muted-foreground font-mono">Other operators can see your bookmarked builds</p>
          </div>
        </label>

        <Button onClick={saveProfile} disabled={savingProfile} className="font-mono uppercase tracking-widest gap-2 w-full sm:w-auto">
          {savingProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : profileSaved ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <Save className="w-4 h-4" />}
          {savingProfile ? "Saving..." : profileSaved ? "Saved!" : "Save Profile"}
        </Button>
      </Section>

      {/* Social Links */}
      <Section icon={LinkIcon} title="Social Links" description="Link your other platforms — displayed on your public profile">
        {([
          { key: "youtube", val: youtubeUrl, set: setYoutubeUrl, label: "YouTube", placeholder: "https://youtube.com/@handle" },
          { key: "instagram", val: instagramUrl, set: setInstagramUrl, label: "Instagram", placeholder: "https://instagram.com/handle" },
          { key: "x", val: xUrl, set: setXUrl, label: "X (Twitter)", placeholder: "https://x.com/handle" },
          { key: "facebook", val: facebookUrl, set: setFacebookUrl, label: "Facebook", placeholder: "https://facebook.com/handle" },
          { key: "tiktok", val: tiktokUrl, set: setTiktokUrl, label: "TikTok", placeholder: "https://tiktok.com/@handle" },
        ] as const).map(({ key, val, set, label, placeholder }) => (
          <div key={key} className="space-y-1">
            <label className="text-xs font-mono text-muted-foreground uppercase">{label}</label>
            <Input value={val} onChange={e => set(e.target.value)} placeholder={placeholder} className="font-mono text-sm" />
          </div>
        ))}

        <Button onClick={saveProfile} disabled={savingProfile} variant="outline" className="font-mono uppercase tracking-widest gap-2 w-full sm:w-auto">
          {savingProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save Links
        </Button>
      </Section>

      {/* Username Change */}
      <Section icon={AlertTriangle} title="Change Callsign" description="Your username and profile URL — changing releases your old callsign immediately">
        <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-sm p-3 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
          <p className="text-xs text-yellow-400/90 font-mono leading-relaxed">
            Changing your callsign updates your profile URL from <code className="bg-secondary px-1 py-0.5 rounded">/u/{profile?.slug}</code> immediately. Your old callsign is released and available for others to claim.
          </p>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-mono text-muted-foreground uppercase">New Callsign</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-mono text-sm">@</span>
            <Input
              value={usernameInput}
              onChange={e => handleUsernameInput(e.target.value)}
              placeholder={profile?.username ?? "new_callsign"}
              className={cn(
                "pl-7 pr-10 font-mono",
                checkState === "available" && "border-green-500/50",
                (checkState === "taken" || (checkState === "invalid" && usernameInput)) && "border-destructive/50",
              )}
              autoComplete="off"
              spellCheck={false}
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2">{usernameStatusIcon()}</span>
          </div>
          <div className="h-4 text-xs font-mono">{usernameStatusText()}</div>
        </div>

        <Button
          onClick={changeUsername}
          disabled={checkState !== "available" || changingUsername}
          variant="outline"
          className="font-mono uppercase tracking-widest gap-2 w-full sm:w-auto border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10"
        >
          {changingUsername ? <Loader2 className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
          {changingUsername ? "Changing..." : "Change Callsign"}
        </Button>
      </Section>
    </div>
  );
}
