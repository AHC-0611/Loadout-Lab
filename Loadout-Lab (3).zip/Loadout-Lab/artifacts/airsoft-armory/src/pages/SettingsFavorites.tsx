import { useGetMyFavorites, useToggleFavorite, getGetMyFavoritesQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Heart, ArrowLeft, Crosshair, DollarSign, User, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney, formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function gunImageUrl(path: string | null | undefined) {
  if (!path) return null;
  return `${BASE}/api/storage${path}`;
}

export default function SettingsFavorites() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useGetMyFavorites();

  const toggleMutation = useToggleFavorite({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMyFavoritesQueryKey() });
      },
    },
  });

  if (isLoading) {
    return (
      <div className="w-full max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-64 w-full" />)}
        </div>
      </div>
    );
  }

  const favorites = data?.favorites ?? [];

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 pb-12">
      {/* Header */}
      <div className="flex items-center gap-4 border-b border-border/50 pb-4">
        <Link href="/settings/profile">
          <Button variant="ghost" size="sm" className="font-mono text-muted-foreground gap-2">
            <ArrowLeft className="w-4 h-4" /> Settings
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-500 fill-red-500" />
          <h1 className="text-xl font-bold tracking-tight">Saved Builds</h1>
          {favorites.length > 0 && (
            <Badge variant="outline" className="font-mono text-xs border-red-500/30 text-red-400">
              {favorites.length}
            </Badge>
          )}
        </div>
      </div>

      {favorites.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-border/50 rounded-sm bg-secondary/10">
          <Heart className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
          <p className="font-mono text-sm text-muted-foreground uppercase tracking-widest mb-1">No saved builds</p>
          <p className="text-xs text-muted-foreground/60 mb-6">Tap the heart on any build to save it here for quick reference</p>
          <Link href="/feed">
            <Button variant="outline" size="sm" className="font-mono uppercase tracking-widest gap-2">
              <Crosshair className="w-3.5 h-3.5" /> Browse Builds
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {favorites.map((f) => {
            const imgUrl = gunImageUrl(f.gunImagePath);
            return (
              <div key={f.id} className="relative group">
                {/* Unfavorite overlay button */}
                <button
                  type="button"
                  onClick={() => toggleMutation.mutate({ id: f.id })}
                  disabled={toggleMutation.isPending}
                  className="absolute top-2 right-2 z-10 bg-card/90 border border-border rounded-sm p-1.5 text-red-500 hover:text-red-400 hover:bg-destructive/10 transition-all opacity-0 group-hover:opacity-100"
                  aria-label="Remove from favorites"
                  title="Remove from favorites"
                >
                  <Heart className="w-3.5 h-3.5 fill-red-500" />
                </button>

                <Link href={`/builds/${f.id}`} className="block h-full hover:no-underline">
                  <Card className="h-full transition-all duration-200 hover:border-primary/50 hover:shadow-[0_0_20px_rgba(249,115,22,0.1)] flex flex-col overflow-hidden">
                    {imgUrl ? (
                      <div className="w-full h-32 overflow-hidden bg-secondary/30 border-b border-border/50 shrink-0">
                        <img
                          src={imgUrl}
                          alt={f.gunName}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          onError={(e) => { (e.currentTarget.parentElement as HTMLElement).style.display = "none"; }}
                        />
                      </div>
                    ) : null}

                    <CardHeader className="pb-2 pt-3">
                      <CardTitle className="text-sm font-bold text-foreground truncate">
                        {f.gunName}
                      </CardTitle>
                      <Badge variant="outline" className="w-fit border-primary/30 text-primary bg-primary/5 text-xs">
                        {f.category}
                      </Badge>
                    </CardHeader>

                    <CardContent className="flex-grow pt-0 pb-2">
                      <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
                        <User className="w-2.5 h-2.5 shrink-0" />
                        <span className="truncate">{f.authorName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground mt-0.5">
                        <Calendar className="w-2.5 h-2.5 shrink-0" />
                        <span>saved {formatDate(f.favoritedAt)}</span>
                      </div>
                    </CardContent>

                    <CardFooter className="pt-2 border-t border-border/50 bg-secondary/10">
                      <div className="flex items-center gap-1 text-primary font-mono font-bold">
                        <DollarSign className="w-3 h-3 shrink-0" />
                        <span className="text-sm">{formatMoney(f.totalCost).replace("$", "")}</span>
                        <span className="text-[10px] text-muted-foreground font-normal ml-0.5">upgrades</span>
                      </div>
                    </CardFooter>
                  </Card>
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
