import { useGetBuildStats } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Terminal, Crosshair, Wrench, BarChart2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: stats, isLoading } = useGetBuildStats();

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] gap-16 py-12">
      {/* Hero Section */}
      <div className="text-center max-w-3xl flex flex-col items-center space-y-6 relative">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.1)_0,transparent_50%)] blur-2xl" />
        
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-secondary/50 border border-primary/20 text-primary text-xs font-mono uppercase tracking-widest mb-4">
          <Terminal className="w-4 h-4" />
          Terminal Active // Global Database
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter uppercase text-foreground leading-[1.1]">
          Engineer Your <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">Perfect Loadout</span>
        </h1>
        
        <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed mt-4">
          The ultimate database for airsoft builders. Document your platform, track upgrade costs, and reverse-engineer the top builds from the community. Stop guessing—start building.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 mt-8 w-full sm:w-auto">
          <Link href="/sign-up">
            <Button size="lg" className="w-full sm:w-auto font-mono uppercase tracking-widest text-primary-foreground gap-2 h-14 px-8 text-base">
              Initialize Profile
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
          <Link href="/search">
            <Button size="lg" variant="outline" className="w-full sm:w-auto font-mono uppercase tracking-widest border-border text-foreground hover:border-primary/50 hover:text-primary gap-2 h-14 px-8 text-base bg-background/50 backdrop-blur">
              <SearchIcon className="w-5 h-5" />
              Access Database
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Section */}
      <div className="w-full max-w-5xl border border-border bg-card/30 backdrop-blur-sm rounded-sm p-8 mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x divide-border/50">
        <div className="flex flex-col items-center text-center px-4 pt-4 md:pt-0">
          <Crosshair className="w-8 h-8 text-primary/80 mb-4" />
          {isLoading ? <Skeleton className="h-10 w-24 mb-2" /> : <div className="text-4xl font-mono font-bold text-foreground mb-2">{stats?.totalBuilds || 0}</div>}
          <div className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Platforms Registered</div>
        </div>
        <div className="flex flex-col items-center text-center px-4 pt-8 md:pt-0">
          <Wrench className="w-8 h-8 text-primary/80 mb-4" />
          {isLoading ? <Skeleton className="h-10 w-24 mb-2" /> : <div className="text-4xl font-mono font-bold text-foreground mb-2">{stats?.totalUpgrades || 0}</div>}
          <div className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Components Tracked</div>
        </div>
        <div className="flex flex-col items-center text-center px-4 pt-8 md:pt-0">
          <BarChart2 className="w-8 h-8 text-primary/80 mb-4" />
          {isLoading ? <Skeleton className="h-10 w-24 mb-2" /> : <div className="text-4xl font-mono font-bold text-foreground mb-2">{stats?.avgUpgradesPerBuild?.toFixed(1) || 0}</div>}
          <div className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Avg Mods / Build</div>
        </div>
      </div>
    </div>
  );
}

function SearchIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}
