import {
  useGetBuild,
  useDeleteBuild,
  useUpsertRating,
  useRemoveRating,
  useToggleFavorite,
  getGetBuildQueryKey,
  getGetMyFavoritesQueryKey,
  getGetMyRatingsQueryKey,
} from "@workspace/api-client-react";
import { useRoute, useLocation, Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatMoney, formatDate } from "@/lib/utils";
import {
  Crosshair, User, Calendar, ExternalLink, Trash2, ArrowLeft,
  Wrench, ShieldAlert, Zap, AlertTriangle, DollarSign, Image as ImageIcon
} from "lucide-react";
import { useUser } from "@clerk/react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { StarRating } from "@/components/StarRating";
import { FavoriteButton } from "@/components/FavoriteButton";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const gunImageUrl = (path: string | null | undefined) =>
  path ? `${BASE}/api/storage${path}` : null;

export default function BuildDetail() {
  const [, params] = useRoute("/builds/:id");
  const [, setLocation] = useLocation();
  const id = Number(params?.id);
  const { user } = useUser();
  const queryClient = useQueryClient();

  const { data: build, isLoading } = useGetBuild(id, {
    query: { enabled: !!id && !isNaN(id), queryKey: getGetBuildQueryKey(id) },
  });

  const deleteMutation = useDeleteBuild({
    mutation: { onSuccess: () => setLocation("/my-builds") },
  });

  // Local engagement state — optimistic until server confirms
  const [localRating, setLocalRating] = useState<number | null | undefined>(undefined);
  const [localFavorited, setLocalFavorited] = useState<boolean | undefined>(undefined);
  const [localFavCount, setLocalFavCount] = useState<number | undefined>(undefined);
  const [localAvg, setLocalAvg] = useState<{ avg: number | null; count: number } | undefined>(undefined);

  const ratingMutation = useUpsertRating({
    mutation: {
      onMutate: ({ id: _id, data }) => {
        setLocalRating(data.rating);
      },
      onSuccess: (data) => {
        setLocalRating(data.myRating ?? null);
        setLocalAvg({ avg: data.averageRating ?? null, count: data.ratingCount });
        queryClient.invalidateQueries({ queryKey: getGetBuildQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getGetMyRatingsQueryKey() });
      },
      onError: () => setLocalRating(undefined),
    },
  });

  const removeRatingMutation = useRemoveRating({
    mutation: {
      onMutate: () => setLocalRating(null),
      onSuccess: (data) => {
        setLocalRating(null);
        setLocalAvg({ avg: data.averageRating ?? null, count: data.ratingCount });
        queryClient.invalidateQueries({ queryKey: getGetBuildQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getGetMyRatingsQueryKey() });
      },
      onError: () => setLocalRating(undefined),
    },
  });

  const favMutation = useToggleFavorite({
    mutation: {
      onMutate: () => {
        const currentFav = localFavorited !== undefined ? localFavorited : (build?.isFavorited ?? false);
        setLocalFavorited(!currentFav);
        setLocalFavCount((localFavCount !== undefined ? localFavCount : (build?.favoriteCount ?? 0)) + (currentFav ? -1 : 1));
      },
      onSuccess: (data) => {
        setLocalFavorited(data.favorited);
        setLocalFavCount(data.favoriteCount);
        queryClient.invalidateQueries({ queryKey: getGetBuildQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getGetMyFavoritesQueryKey() });
      },
      onError: () => {
        setLocalFavorited(undefined);
        setLocalFavCount(undefined);
      },
    },
  });

  const [confirmDelete, setConfirmDelete] = useState(false);

  if (isLoading) {
    return (
      <div className="w-full max-w-4xl mx-auto space-y-6">
        <Skeleton className="h-10 w-32 mb-8" />
        <Skeleton className="h-64 w-full rounded-sm" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-64 md:col-span-2" />
          <Skeleton className="h-64 md:col-span-1" />
        </div>
      </div>
    );
  }

  if (!build) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ShieldAlert className="w-12 h-12 text-destructive mb-4" />
        <h2 className="text-xl font-bold mb-2">Record Not Found</h2>
        <p className="text-muted-foreground mb-6">This build has been expunged or does not exist.</p>
        <Link href="/feed">
          <Button variant="outline" className="font-mono uppercase tracking-widest gap-2">
            <ArrowLeft className="w-4 h-4" /> Return to Feed
          </Button>
        </Link>
      </div>
    );
  }

  const isOwner = user?.id === build.userId;
  const imgUrl = gunImageUrl(build.gunImagePath);
  const upgradeOnlyCost = build.totalCost;
  const totalWithGun = build.baseCost != null ? build.baseCost + upgradeOnlyCost : null;

  // Resolve display values (local optimistic state wins over server state)
  const displayRating = localRating !== undefined ? localRating : (build.myRating ?? null);
  const displayFavorited = localFavorited !== undefined ? localFavorited : build.isFavorited;
  const displayFavCount = localFavCount !== undefined ? localFavCount : build.favoriteCount;
  const displayAvg = localAvg?.avg !== undefined ? localAvg.avg : build.averageRating;
  const displayRatingCount = localAvg?.count !== undefined ? localAvg.count : build.ratingCount;

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-8 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">

      {/* Header Actions */}
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <Link href="/feed">
          <Button variant="ghost" size="sm" className="font-mono text-muted-foreground hover:text-foreground gap-2">
            <ArrowLeft className="w-4 h-4" /> Back to Feed
          </Button>
        </Link>
        {isOwner && (
          <div className="flex items-center gap-2">
            {confirmDelete && <span className="text-xs text-destructive font-mono font-bold animate-pulse">Confirm?</span>}
            <Button
              variant={confirmDelete ? "destructive" : "outline"}
              size="sm"
              onClick={() => confirmDelete ? deleteMutation.mutate({ id: build.id }) : setConfirmDelete(true)}
              disabled={deleteMutation.isPending}
              className="font-mono text-xs uppercase tracking-widest gap-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              {deleteMutation.isPending ? "Expunging..." : confirmDelete ? "Execute" : "Delete Build"}
            </Button>
            {confirmDelete && (
              <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(false)} className="font-mono text-xs">Cancel</Button>
            )}
          </div>
        )}
      </div>

      {/* Gun Photo Hero */}
      {imgUrl && (
        <div className="w-full rounded-sm overflow-hidden border border-border bg-secondary/20" style={{ maxHeight: "420px" }}>
          <img
            src={imgUrl}
            alt={build.gunName}
            className="w-full h-full object-cover"
            style={{ maxHeight: "420px" }}
            onError={(e) => { (e.currentTarget.parentElement as HTMLElement).style.display = "none"; }}
          />
        </div>
      )}

      {/* Main Info */}
      <div className="flex flex-col lg:flex-row gap-8 items-start">
        <div className="flex-1 space-y-6 min-w-0">
          <div>
            <div className="flex items-start gap-3 mb-2">
              <Crosshair className="w-7 h-7 text-primary mt-1 shrink-0" />
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground leading-tight">{build.gunName}</h1>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <Badge variant="outline" className="border-primary/50 text-primary bg-primary/10 px-3 py-1 max-w-[200px] truncate">
                {build.category}
              </Badge>
              {build.specialty && (
                <Badge variant="outline" className="border-yellow-500/50 text-yellow-400 bg-yellow-500/10 px-3 py-1 flex items-center gap-1 max-w-[220px]">
                  <Zap className="w-3 h-3 shrink-0" />
                  <span className="truncate">{build.specialty}</span>
                </Badge>
              )}
              {/* Author — clickable if they have a slug */}
              <span className="flex items-center gap-1.5 text-sm font-mono text-muted-foreground">
                <User className="w-3.5 h-3.5 shrink-0" />
                {build.authorSlug ? (
                  <Link href={`/u/${build.authorSlug}`} className="hover:text-primary transition-colors">
                    {build.authorName}
                  </Link>
                ) : (
                  <span>{build.authorName}</span>
                )}
              </span>
              <span className="flex items-center gap-1.5 text-sm font-mono text-muted-foreground">
                <Calendar className="w-3.5 h-3.5" /> {formatDate(build.createdAt)}
              </span>
            </div>
          </div>

          {/* Engagement Widget */}
          <div className="bg-secondary/20 border border-border rounded-sm p-4 flex flex-col sm:flex-row gap-6">
            {/* Rating */}
            <div className="flex-1">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-2">
                {user ? "Your Rating" : "Community Rating"}
              </p>
              <StarRating
                averageRating={displayAvg}
                ratingCount={displayRatingCount}
                myRating={user ? displayRating : null}
                onRate={user ? (v) => ratingMutation.mutate({ id: build.id, data: { rating: v } }) : undefined}
                onRemove={user ? () => removeRatingMutation.mutate({ id: build.id }) : undefined}
                isPending={ratingMutation.isPending || removeRatingMutation.isPending}
              />
              {!user && (
                <p className="text-[10px] font-mono text-muted-foreground/60 mt-1">
                  <Link href={`${BASE}/sign-in`} className="text-primary hover:underline">Sign in</Link> to rate this build
                </p>
              )}
            </div>

            {/* Divider */}
            <div className="w-px bg-border/50 hidden sm:block" />

            {/* Favorite */}
            <div className="flex flex-col gap-2">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Save Build
              </p>
              <div className="flex items-center gap-3">
                <FavoriteButton
                  favorited={displayFavorited}
                  favoriteCount={displayFavCount}
                  showCount
                  size="md"
                  onToggle={() => favMutation.mutate({ id: build.id })}
                  isPending={favMutation.isPending}
                />
                <span className="text-xs font-mono text-muted-foreground">
                  {displayFavorited ? "Saved to favorites" : `${displayFavCount} saved`}
                </span>
              </div>
            </div>
          </div>

          {build.description && (
            <div className="bg-secondary/20 border border-border p-5 rounded-sm text-foreground/90 leading-relaxed whitespace-pre-wrap text-sm">
              {build.description}
            </div>
          )}

          {build.cons && (
            <div className="bg-yellow-500/5 border border-yellow-500/20 p-5 rounded-sm">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />
                <h3 className="text-xs font-mono uppercase tracking-widest text-yellow-500 font-bold">Known Drawbacks</h3>
              </div>
              <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">{build.cons}</p>
            </div>
          )}
        </div>

        {/* Cost Summary */}
        <div className="w-full lg:w-64 shrink-0 bg-card border border-border rounded-sm overflow-hidden lg:sticky lg:top-24">
          <div className="bg-secondary/50 p-4 border-b border-border">
            <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Upgrade Cost</h3>
            <div className="text-3xl font-bold text-primary font-mono mt-1">{formatMoney(upgradeOnlyCost)}</div>
            <p className="text-[10px] text-muted-foreground font-mono mt-0.5">Parts &amp; upgrades only</p>
          </div>
          <div className="p-4 flex flex-col gap-3 text-sm font-mono">
            {build.baseCost != null && (
              <>
                <div className="flex justify-between items-center text-muted-foreground border-b border-border/50 pb-3">
                  <span className="flex items-center gap-1.5"><DollarSign className="w-3 h-3" />Base Gun</span>
                  <span className="text-foreground">{formatMoney(build.baseCost)}</span>
                </div>
                <div className="flex justify-between items-center border-b border-border/50 pb-3">
                  <span className="text-foreground font-bold text-xs">Total (Gun + Upgrades)</span>
                  <span className="text-primary font-bold">{formatMoney(totalWithGun!)}</span>
                </div>
              </>
            )}
            <div className="flex justify-between items-center text-muted-foreground border-b border-border/50 pb-2">
              <span>Upgrades</span>
              <span className="text-foreground">{build.upgrades?.length || 0}</span>
            </div>
            <div className="flex justify-between items-center text-muted-foreground">
              <span>Avg Part Cost</span>
              <span className="text-foreground">
                {build.upgrades?.length ? formatMoney(upgradeOnlyCost / build.upgrades.length) : "$0.00"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Upgrades Manifest */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 border-b border-border pb-2">
          <Wrench className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold uppercase tracking-widest">Components Manifest</h2>
        </div>

        {build.upgrades && build.upgrades.length > 0 ? (
          <div className="space-y-3">
            {build.upgrades.map((mod) => (
              <div key={mod.id} className="flex flex-col sm:flex-row gap-4 p-4 border border-border bg-card/50 rounded-sm hover:border-primary/30 transition-colors">
                <div className="w-full sm:w-20 h-20 shrink-0 rounded-sm overflow-hidden border border-border bg-secondary/30 flex items-center justify-center">
                  {mod.imageUrl ? (
                    <img
                      src={mod.imageUrl}
                      alt={mod.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.currentTarget.style.display = "none");
                        const next = e.currentTarget.nextElementSibling as HTMLElement | null;
                        if (next) next.style.display = "flex";
                      }}
                    />
                  ) : null}
                  <ImageIcon className={`w-6 h-6 text-muted-foreground/30 ${mod.imageUrl ? "hidden" : ""}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium text-foreground truncate">{mod.name}</p>
                      {mod.source && (
                        <a href={mod.source} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs font-mono text-primary/70 hover:text-primary transition-colors mt-1">
                          <ExternalLink className="w-3 h-3" /> Buy this part
                        </a>
                      )}
                    </div>
                    <span className="shrink-0 text-primary font-bold font-mono text-lg">{formatMoney(mod.price)}</span>
                  </div>
                </div>
              </div>
            ))}
            <div className="flex justify-between items-center px-4 py-3 bg-secondary/30 border border-border rounded-sm font-mono">
              <span className="text-sm text-muted-foreground uppercase tracking-widest">Upgrade Total</span>
              <span className="text-primary font-bold text-lg">{formatMoney(upgradeOnlyCost)}</span>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 border border-dashed border-border/50 rounded-sm bg-secondary/10">
            <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">No components registered</p>
          </div>
        )}
      </div>
    </div>
  );
}
