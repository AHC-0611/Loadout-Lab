import { useGetMyBuilds } from "@workspace/api-client-react";
import { BuildCard } from "@/components/BuildCard";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function MyBuilds() {
  const { data, isLoading } = useGetMyBuilds();

  return (
    <div className="w-full flex flex-col gap-6">
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <div className="flex items-center gap-3">
          <User className="w-5 h-5 text-primary" />
          <h1 className="text-2xl font-bold font-sans uppercase tracking-tight">My Armory</h1>
        </div>
        <Link href="/post">
          <Button variant="default" size="sm" className="font-mono uppercase tracking-wider gap-2">
            <Plus className="w-4 h-4" /> Register New
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      ) : data?.builds.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-32 text-center border border-dashed border-border/50 bg-secondary/10 rounded-sm">
          <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-6 border border-border">
            <Plus className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2 uppercase tracking-wide">Armory Empty</h2>
          <p className="text-sm text-muted-foreground max-w-md mb-8">
            You haven't registered any platforms yet. Document your first build to start tracking loadout data.
          </p>
          <Link href="/post">
            <Button variant="default" className="font-mono uppercase tracking-widest gap-2">
              <Plus className="w-4 h-4" /> Post Build
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data?.builds.map((build, i) => (
            <div 
              key={build.id} 
              className="animate-in fade-in slide-in-from-bottom-4 fill-mode-both"
              style={{ animationDelay: `${i * 50}ms`, animationDuration: '500ms' }}
            >
              <BuildCard build={build} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
