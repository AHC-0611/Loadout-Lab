import { useEffect, useRef, useState } from "react";
import { useUser } from "@clerk/react";
import { useLocation, Redirect } from "wouter";
import { Crosshair, CheckCircle2, XCircle, Loader2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useProfile } from "@/context/ProfileContext";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;

type CheckState = "idle" | "checking" | "available" | "taken" | "invalid";

export default function SetupUsername() {
  const { user, isLoaded } = useUser();
  const { hasProfile, isLoading: profileLoading, refetchProfile } = useProfile();
  const [, setLocation] = useLocation();

  const [input, setInput] = useState("");
  const [checkState, setCheckState] = useState<CheckState>("idle");
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Redirect if already has profile
  if (isLoaded && !profileLoading && hasProfile) {
    return <Redirect to="/feed" />;
  }

  if (!isLoaded || profileLoading) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center">
        <Crosshair className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) return <Redirect to="/sign-in" />;

  const handleInputChange = (value: string) => {
    setInput(value);
    setServerError(null);
    if (timerRef.current) clearTimeout(timerRef.current);

    if (!value) {
      setCheckState("idle");
      return;
    }

    if (!USERNAME_RE.test(value)) {
      setCheckState("invalid");
      return;
    }

    setCheckState("checking");
    timerRef.current = setTimeout(async () => {
      try {
        const res = await fetch(
          `${BASE}/api/profiles/check-username?username=${encodeURIComponent(value)}`,
        );
        const data = await res.json();
        setCheckState(data.available ? "available" : "taken");
      } catch {
        setCheckState("idle");
      }
    }, 500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (checkState !== "available" || submitting) return;

    setSubmitting(true);
    setServerError(null);
    try {
      const res = await fetch(`${BASE}/api/profiles/me/setup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: input }),
      });
      if (res.ok) {
        await refetchProfile();
        setLocation("/feed");
      } else {
        const data = await res.json();
        setServerError(data.error ?? "Setup failed. Try again.");
        setCheckState("taken");
      }
    } catch {
      setServerError("Network error. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const statusIcon = () => {
    if (checkState === "checking") return <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />;
    if (checkState === "available") return <CheckCircle2 className="w-4 h-4 text-green-500" />;
    if (checkState === "taken") return <XCircle className="w-4 h-4 text-destructive" />;
    if (checkState === "invalid" && input.length > 0) return <XCircle className="w-4 h-4 text-destructive" />;
    return null;
  };

  const statusText = () => {
    if (checkState === "available") return <span className="text-green-500">Callsign available</span>;
    if (checkState === "taken") return <span className="text-destructive">{serverError ?? "Callsign already taken"}</span>;
    if (checkState === "invalid" && input.length > 0) return <span className="text-destructive">3–30 characters: letters, numbers, and _ only</span>;
    return null;
  };

  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.05)_0,transparent_50%)]" />

      <div className="w-full max-w-md space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Crosshair className="w-8 h-8 text-primary" />
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Claim Your Callsign</h1>
            <p className="text-muted-foreground font-mono text-sm mt-2">
              Your username is your permanent identity in the Armory.
            </p>
          </div>
        </div>

        {/* Form */}
        <div className="bg-card border border-border rounded-sm p-8 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                Choose Username
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-mono text-sm">@</span>
                <Input
                  value={input}
                  onChange={(e) => handleInputChange(e.target.value)}
                  placeholder="your_callsign"
                  className={cn(
                    "pl-7 pr-10 font-mono h-11",
                    checkState === "available" && "border-green-500/50 focus-visible:ring-green-500/30",
                    (checkState === "taken" || (checkState === "invalid" && input)) && "border-destructive/50 focus-visible:ring-destructive/30",
                  )}
                  autoComplete="off"
                  autoFocus
                  spellCheck={false}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2">
                  {statusIcon()}
                </span>
              </div>
              <div className="h-4 text-xs font-mono">{statusText()}</div>
            </div>

            <Button
              type="submit"
              className="w-full h-11 font-mono uppercase tracking-widest gap-2"
              disabled={checkState !== "available" || submitting}
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
              {submitting ? "Claiming..." : "Deploy Operator"}
            </Button>
          </form>

          {/* Requirements */}
          <div className="border-t border-border/50 pt-4 space-y-1.5">
            <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Requirements</p>
            {[
              "3 to 30 characters",
              "Letters, numbers, and underscores only",
              "No spaces or special characters",
              "Not already taken by another operator",
            ].map((r) => (
              <p key={r} className="text-xs text-muted-foreground font-mono flex items-center gap-2">
                <span className="text-primary">—</span> {r}
              </p>
            ))}
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground font-mono">
          You can change your callsign later in profile settings.
        </p>
      </div>
    </div>
  );
}
