import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useCreateBuild, getListBuildsQueryKey, getGetMyBuildsQueryKey, getGetBuildStatsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Save, Terminal, Info, Link as LinkIcon, DollarSign, Image as ImageIcon, Zap, AlertTriangle, Camera, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUpload } from "@workspace/object-storage-web";
import { useEffect, useRef, useState } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const upgradeSchema = z.object({
  name: z.string().min(1, "Component name is required"),
  price: z.coerce.number().min(0, "Price must be positive"),
  source: z.string().optional(),
  imageUrl: z.string().optional(),
});

const formSchema = z.object({
  gunName: z.string().min(1, "Designation is required"),
  category: z.string().min(1, "Category is required"),
  description: z.string().optional(),
  baseCost: z.coerce.number().min(0).optional(),
  specialty: z.string().optional(),
  cons: z.string().optional(),
  gunImagePath: z.string().optional(),
  upgrades: z.array(upgradeSchema),
});

type FormValues = z.infer<typeof formSchema>;

function useOgImageSuggestion(url: string | undefined, enabled: boolean) {
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setSuggestion(null);
    if (!enabled || !url || !url.startsWith("http")) return;
    timerRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`${BASE}/api/og-image?url=${encodeURIComponent(url)}`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.found && data.imageUrl) setSuggestion(data.imageUrl);
      } catch {}
      finally { setLoading(false); }
    }, 800);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [url, enabled]);

  return { suggestion, loading };
}

function UpgradeRow({
  index, register, errors, remove, watch, setValue,
}: {
  index: number;
  register: any;
  errors: any;
  remove: (i: number) => void;
  watch: any;
  setValue: any;
}) {
  const sourceUrl = watch(`upgrades.${index}.source`);
  const imageUrl = watch(`upgrades.${index}.imageUrl`);
  const { suggestion, loading } = useOgImageSuggestion(sourceUrl, true);

  return (
    <div className="p-4 border border-border bg-card/50 rounded-sm space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Component #{index + 1}</span>
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => remove(index)}>
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-[10px] font-mono text-muted-foreground uppercase">Component Name *</label>
          <Input {...register(`upgrades.${index}.name`)} placeholder="e.g. Prometheus 6.03 EG Barrel" className={cn("h-8 text-xs", errors.upgrades?.[index]?.name && "border-destructive")} />
          {errors.upgrades?.[index]?.name && <p className="text-[10px] text-destructive font-mono">{errors.upgrades[index]?.name?.message}</p>}
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-mono text-muted-foreground uppercase">Cost (USD)</label>
          <div className="relative">
            <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input type="number" step="0.01" {...register(`upgrades.${index}.price`)} className={cn("h-8 text-xs pl-7", errors.upgrades?.[index]?.price && "border-destructive")} />
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-mono text-muted-foreground uppercase flex items-center gap-1">
          <LinkIcon className="w-3 h-3" /> Buy Link (Optional)
        </label>
        <div className="flex items-center gap-2">
          <Input {...register(`upgrades.${index}.source`)} placeholder="https://evike.com/products/..." className="h-8 text-xs flex-1" />
          {loading && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground shrink-0" />}
        </div>
      </div>

      {/* og:image suggestion */}
      {suggestion && !imageUrl && (
        <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/20 rounded-sm">
          <img src={suggestion} alt="Suggested part" className="w-14 h-14 object-cover rounded-sm border border-border bg-secondary" onError={e => (e.currentTarget.style.display = "none")} />
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-mono text-primary uppercase tracking-widest flex items-center gap-1 mb-1">
              <Sparkles className="w-3 h-3" /> Image found from link
            </p>
            <Button type="button" size="sm" variant="outline" className="h-7 text-xs font-mono gap-1.5" onClick={() => setValue(`upgrades.${index}.imageUrl`, suggestion)}>
              Use this photo
            </Button>
          </div>
        </div>
      )}

      {/* Part image field */}
      <div className="space-y-2">
        <label className="text-[10px] font-mono text-muted-foreground uppercase flex items-center gap-1">
          <ImageIcon className="w-3 h-3" /> Part Photo URL (Optional)
        </label>
        <div className="flex gap-2 items-center">
          <Input {...register(`upgrades.${index}.imageUrl`)} placeholder="https://... (auto-filled from link, or paste your own)" className="h-8 text-xs flex-1" />
          {imageUrl && (
            <img src={imageUrl} alt="Part preview" className="w-8 h-8 object-cover rounded-sm border border-border bg-secondary shrink-0" onError={e => (e.currentTarget.style.display = "none")} />
          )}
        </div>
      </div>
    </div>
  );
}

export default function PostBuild() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [gunPreview, setGunPreview] = useState<string | null>(null);

  const { uploadFile, isUploading } = useUpload({
    basePath: `${BASE}/api/storage`,
    onSuccess: (r) => {
      setValue("gunImagePath", r.objectPath);
      setGunPreview(`${BASE}/api/storage${r.objectPath}`);
    },
  });

  const createMutation = useCreateBuild({
    mutation: {
      onSuccess: (build) => {
        queryClient.invalidateQueries({ queryKey: getListBuildsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMyBuildsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBuildStatsQueryKey() });
        setLocation(`/builds/${build.id}`);
      },
    },
  });

  const { register, control, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { gunName: "", category: "", description: "", specialty: "", cons: "", gunImagePath: "", upgrades: [] },
  });

  const { fields, append, remove } = useFieldArray({ control, name: "upgrades" });

  const onSubmit = (data: FormValues) => {
    createMutation.mutate({
      data: {
        gunName: data.gunName,
        category: data.category,
        description: data.description ?? "",
        baseCost: data.baseCost,
        specialty: data.specialty || undefined,
        cons: data.cons || undefined,
        gunImagePath: data.gunImagePath || undefined,
        upgrades: data.upgrades.map(u => ({
          name: u.name, price: u.price, source: u.source ?? "", imageUrl: u.imageUrl || undefined,
        })),
      },
    });
  };

  return (
    <div className="w-full max-w-3xl mx-auto pb-20">
      <div className="flex items-center gap-3 border-b border-border/50 pb-4 mb-8">
        <Terminal className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-bold font-sans uppercase tracking-tight">Add Build</h1>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-10">

        {/* Gun Photo */}
        <div className="space-y-4 bg-card border border-border p-6 rounded-sm">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-mono uppercase tracking-widest text-muted-foreground font-bold">Gun Photo (Optional)</h2>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            {/* Preview */}
            <div className={cn(
              "w-full sm:w-40 h-32 rounded-sm border border-border bg-secondary/20 flex items-center justify-center overflow-hidden shrink-0",
              gunPreview && "border-primary/30"
            )}>
              {gunPreview
                ? <img src={gunPreview} alt="Gun preview" className="w-full h-full object-cover" />
                : <Camera className="w-8 h-8 text-muted-foreground/30" />
              }
            </div>
            <div className="flex-1 space-y-3">
              <p className="text-xs text-muted-foreground font-mono">Show off your platform. Upload a photo of your gun — this displays at the top of your build page and on the feed card.</p>
              <label className={cn(
                "flex items-center gap-2 cursor-pointer px-4 py-2 rounded-sm border border-border text-sm font-mono uppercase tracking-widest transition-colors w-fit",
                isUploading ? "opacity-50 cursor-not-allowed" : "hover:border-primary/50 hover:text-primary hover:bg-primary/5"
              )}>
                {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
                {isUploading ? "Uploading..." : gunPreview ? "Replace Photo" : "Upload Photo"}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  disabled={isUploading}
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) await uploadFile(file);
                    e.target.value = "";
                  }}
                />
              </label>
              {gunPreview && (
                <button type="button" className="text-xs text-muted-foreground hover:text-destructive font-mono" onClick={() => { setValue("gunImagePath", ""); setGunPreview(null); }}>
                  Remove photo
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Core Specs */}
        <div className="space-y-6 bg-card border border-border p-6 rounded-sm">
          <div className="flex items-center gap-2 mb-4">
            <Info className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-mono uppercase tracking-widest text-muted-foreground font-bold">Core Specifications</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Platform Designation *</label>
              <Input {...register("gunName")} placeholder="e.g. VFC Avalon MK18" className={cn(errors.gunName && "border-destructive")} />
              {errors.gunName && <p className="text-xs text-destructive font-mono">{errors.gunName.message}</p>}
            </div>
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground uppercase">Classification *</label>
              <Input {...register("category")} placeholder="e.g. AEG, HPA, GBB Pistol" className={cn(errors.category && "border-destructive")} />
              {errors.category && <p className="text-xs text-destructive font-mono">{errors.category.message}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">
              Base Gun Price (Optional) — <span className="text-primary/80">upgrades listed below are separate from this</span>
            </label>
            <div className="relative max-w-xs">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input type="number" step="0.01" min="0" {...register("baseCost")} placeholder="e.g. 280.00" className="pl-8" />
            </div>
            <p className="text-xs text-muted-foreground font-mono">Helps viewers know the total cost to build from scratch</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-primary" /> Specialty / Role (Optional)
            </label>
            <Input {...register("specialty")} placeholder="e.g. High Range, High ROF, Fast Cycling, CQB" />
            <p className="text-xs text-muted-foreground font-mono">Describe what this platform excels at</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase">Tactical Briefing (Description)</label>
            <Textarea {...register("description")} placeholder="Detail your build goals, performance numbers (FPS/RPS), and insights..." className="min-h-[120px]" />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-muted-foreground uppercase flex items-center gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-yellow-500" /> Known Drawbacks (Optional)
            </label>
            <Textarea {...register("cons")} placeholder="e.g. Heavy trigger pull, inconsistent hop-up, tight battery compartment..." className="min-h-[80px]" />
            <p className="text-xs text-muted-foreground font-mono">Honest cons help other builders make informed decisions</p>
          </div>
        </div>

        {/* Upgrades */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-border/50 pb-2">
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-primary" />
              <h2 className="text-sm font-mono uppercase tracking-widest text-muted-foreground font-bold">Component Manifest</h2>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={() => append({ name: "", price: 0, source: "", imageUrl: "" })} className="font-mono text-xs gap-2">
              <Plus className="w-3 h-3" /> Add Component
            </Button>
          </div>
          <p className="text-xs text-muted-foreground font-mono -mt-2">
            Paste a buy link from an approved store and the part photo is suggested automatically.
          </p>

          {fields.length === 0 ? (
            <div className="text-center py-8 border border-dashed border-border/50 rounded-sm bg-secondary/10">
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest">No components recorded yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {fields.map((field, index) => (
                <UpgradeRow key={field.id} index={index} register={register} errors={errors} remove={remove} watch={watch} setValue={setValue} />
              ))}
            </div>
          )}
        </div>

        <div className="pt-6 flex justify-end">
          <Button type="submit" size="lg" disabled={createMutation.isPending || isUploading} className="w-full md:w-auto font-mono uppercase tracking-widest gap-2 h-12 px-8">
            <Save className="w-4 h-4" />
            {createMutation.isPending ? "Transmitting..." : "Commit Build to Database"}
          </Button>
        </div>
      </form>
    </div>
  );
}
