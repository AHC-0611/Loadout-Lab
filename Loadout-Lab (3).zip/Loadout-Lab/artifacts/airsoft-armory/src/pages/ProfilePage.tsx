import { useState } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { useUser } from "@clerk/react";
import { useProfile } from "@/context/ProfileContext";
import {
  ExternalLink, Copy, Check, Edit2, Terminal,
  Youtube, Instagram, Facebook, Twitter, Music2, ShieldAlert, Heart,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BuildCard } from "@/components/BuildCard";
import { avatarUrl } from "@/context/ProfileContext";
import { useGetPublicProfile } from "@workspace/api-client-react";
import type { PublicProfile, FavoritedBuild } from "@workspace/api-client-react";
import { formatMoney } from "@/lib/utils";
import { DollarSign, User } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { SocialButtons } from "@/components/SocialButtons";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function gunImageUrl(path: string | null | undefined) {
  if (!path) return null;
  return `${BASE}/api/storage${path}`;
}

const SOCIAL_LINKS = [
  { key: "youtubeUrl" as const, label: "YouTube", Icon: Youtube, color: "text-red-500 hover:text-red-400", bg: "hover:bg-red-500/10" },
  { key: "instagramUrl" as const, label: "Instagram", Icon: Instagram, color: "text-pink-500 hover:text-pink-400", bg: "hover:bg-pink-500/10" },
  { key: "xUrl" as const, label: "X", Icon: Twitter, color: "text-foreground hover:text-foreground/80", bg: "hover:bg-secondary" },
  { key: "facebookUrl" as const, label: "Facebook", Icon: Facebook, color: "text-blue-500 hover:text-blue-400", bg: "hover:bg-blue-500/10" },
  { key: "tiktokUrl" as const, label: "TikTok", Icon: Music2, color: "text-foreground hover:text-foreground/80", bg: "hover:bg-secondary" },
];

function AvatarCircle({ profile, size = "lg" }: { profile: PublicProfile; size?: "sm" | "lg" }) {
  const url = avatarUrl(profile.avatarPath);
  const dim = size === "lg" ? "w-24 h-24 text-3xl" : "w-10 h-10 text-sm";
  return (
    <div className={`${dim} rounded-full border-2 border-border bg-secondary flex items-center justify-center overflow-hidden shrink-0`}>
      {url ? (
        <img src={url} alt={profile.username} className="w-full h-full object-cover"
          onError={(e) => { (e.currentTarget.style.display = "none"); }} />
      ) : (
        <span className="font-bold text-primary uppercase">
          {profile.username[0]}
        </span>
      )}
    </div>
  );
}

/** Compact favorited build card for the public profile section */
function FavCard({ f }: { f: FavoritedBuild & { favoritedAt: string } }) {
  const imgUrl = gunImageUrl(f.gunImagePath);
  return (
    <Link href={`/builds/${f.id}`} className="block hover:no-underline group">
      <Card className="h-full transition-all duration-200 hover:border-primary/50 flex flex-col overflow-hidden">
        {imgUrl && (
          <div className="w-full h-28 overflow-hidden bg-secondary/30 border-b border-border/50 shrink-0">
            <img src={imgUrl} alt={f.gunName} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              onError={(e) => { (e.currentTarget.parentElement as HTMLElement).style.display = "none"; }} />
          </div>
        )}
        <CardHeader className="pb-1 pt-3">
          <CardTitle className="text-sm font-bold text-foreground truncate group-hover:text-primary transition-colors">{f.gunName}</CardTitle>
          <Badge variant="outline" className="w-fit border-primary/30 text-primary bg-primary/5 text-[10px]">{f.category}</Badge>
        </CardHeader>
        <CardContent className="flex-grow pt-0 pb-1">
          <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
            <User className="w-2.5 h-2.5" />
            <span className="truncate">{f.authorName}</span>
          </div>
        </CardContent>
        <CardFooter className="pt-2 border-t border-border/50 bg-secondary/10">
          <div className="flex items-center gap-1 text-primary font-mono font-bold text-sm">
            <DollarSign className="w-3 h-3" />
            {formatMoney(f.totalCost).replace("$", "")}
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}

export default function ProfilePage() {
  const [, params] = useRoute("/u/:slug");
  const { user } = useUser();
  const { profile: myProfile } = useProfile();
  const [, setLocation] = useLocation();
  const [copied, setCopied] = useState(false);

  const slug = params?.slug ?? "";

  const { data: profile, isLoading: loading } = useGetPublicProfile(slug);

  const copyUrl = () => {
    const url = `${window.location.origin}${BASE}/u/${slug}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (loading) {
    return (
      <div className="w-full max-w-4xl mx-auto space-y-8">
        <div className="flex items-start gap-6">
          <Skeleton className="w-24 h-24 rounded-full shrink-0" />
          <div className="flex-1 space-y-3">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-16 w-full" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-64" />)}
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <ShieldAlert className="w-12 h-12 text-destructive mb-4" />
        <h2 className="text-xl font-bold mb-2">Operator Not Found</h2>
        <p className="text-muted-foreground mb-6 font-mono text-sm">
          This callsign doesn't exist in the registry.
        </p>
        <Link href="/feed">
          <Button variant="outline" className="font-mono uppercase tracking-widest">
            Return to Feed
          </Button>
        </Link>
      </div>
    );
  }

  const isOwnProfile = !!myProfile && myProfile.slug === slug;
  const socialLinks = SOCIAL_LINKS.filter((s) => !!profile[s.key]);
  const publicFavorites = profile.publicFavorites ?? [];

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-10 pb-12">

      {/* Profile Header */}
      <div className="relative overflow-hidden rounded-sm border border-border">
        <div
          className="absolute inset-0 -z-10"
          style={{
            background: profile.profileBgColor
              ? `linear-gradient(135deg, ${profile.profileBgColor}22 0%, transparent 60%)`
              : "linear-gradient(135deg, rgba(249,115,22,0.05) 0%, transparent 60%)",
          }}
        />
        <div className="p-6 md:p-8 flex flex-col sm:flex-row gap-6 items-start">
          <AvatarCircle profile={profile} size="lg" />

          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-start gap-3 mb-1">
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                {profile.displayName || profile.username}
              </h1>
              {profile.isVerified && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-mono font-bold bg-yellow-500/10 border border-yellow-500/30 text-yellow-400">
                  ✓ Verified
                </span>
              )}
            </div>
            <p className="text-sm font-mono text-muted-foreground mb-3">
              @{profile.username} · <span>{profile.buildCount} build{profile.buildCount !== 1 ? "s" : ""}</span>
            </p>

            {/* Social counts */}
            <div className="flex flex-wrap gap-4 mb-3 text-sm font-mono">
              <span className="text-muted-foreground">
                <span className="text-foreground font-bold">{profile.followerCount}</span>{" "}
                follower{profile.followerCount !== 1 ? "s" : ""}
              </span>
              <span className="text-muted-foreground">
                <span className="text-foreground font-bold">{profile.followingCount}</span>{" "}
                following
              </span>
              <span className="text-muted-foreground">
                <span className="text-foreground font-bold">{profile.friendCount}</span>{" "}
                friend{profile.friendCount !== 1 ? "s" : ""}
              </span>
            </div>

            {profile.bio && (
              <p className="text-sm text-foreground/80 leading-relaxed mb-4 whitespace-pre-wrap max-w-xl">
                {profile.bio}
              </p>
            )}

            {socialLinks.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {socialLinks.map(({ key, label, Icon, color, bg }) => (
                  <a
                    key={key}
                    href={profile[key]!}
                    target="_blank"
                    rel="noreferrer"
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-border text-xs font-mono transition-colors ${color} ${bg}`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                    <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                  </a>
                ))}
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {!isOwnProfile && (
                <SocialButtons
                  slug={slug}
                  isFollowing={profile.isFollowing}
                  isMutual={profile.isMutual}
                  friendshipStatus={profile.friendshipStatus}
                  friendRequestId={profile.friendRequestId}
                />
              )}
              <Button variant="outline" size="sm" onClick={copyUrl} className="font-mono text-xs gap-2 uppercase tracking-wider">
                {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "Copied!" : "Copy Profile URL"}
              </Button>
              {isOwnProfile && (
                <>
                  <Link href="/settings/profile">
                    <Button variant="ghost" size="sm" className="font-mono text-xs gap-2 uppercase tracking-wider text-muted-foreground">
                      <Edit2 className="w-3.5 h-3.5" />
                      Edit Profile
                    </Button>
                  </Link>
                  <Link href="/settings/connections">
                    <Button variant="ghost" size="sm" className="font-mono text-xs gap-2 uppercase tracking-wider text-muted-foreground">
                      <Users className="w-3.5 h-3.5" />
                      Connections
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Builds */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 border-b border-border/50 pb-2">
          <Terminal className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold uppercase tracking-widest">
            Build Manifest <span className="text-muted-foreground font-mono font-normal text-sm">({profile.buildCount})</span>
          </h2>
        </div>

        {profile.builds.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-border/50 rounded-sm bg-secondary/10">
            <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">
              No builds registered yet
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {profile.builds.map((build, i) => (
              <div
                key={build.id}
                className="animate-in fade-in slide-in-from-bottom-4 fill-mode-both"
                style={{ animationDelay: `${i * 50}ms`, animationDuration: "400ms" }}
              >
                <BuildCard build={build} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Public Favorites section — only shown if showFavoritesPublic is true */}
      {profile.showFavoritesPublic && publicFavorites.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 border-b border-border/50 pb-2">
            <Heart className="w-5 h-5 text-red-500 fill-red-500" />
            <h2 className="text-lg font-bold uppercase tracking-widest">
              Favorite Builds{" "}
              <span className="text-muted-foreground font-mono font-normal text-sm">({publicFavorites.length})</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {publicFavorites.map((f) => (
              <FavCard key={f.id} f={f} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
