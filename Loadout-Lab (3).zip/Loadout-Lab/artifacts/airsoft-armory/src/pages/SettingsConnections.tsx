import { useState } from "react";
import { Link } from "wouter";
import { useUser } from "@clerk/react";
import {
  useGetIncomingFriendRequests,
  useGetOutgoingFriendRequests,
  useGetFriends,
  useGetFollowers,
  useGetFollowing,
  useRespondToFriendRequest,
  useCancelOrRemoveFriendRequest,
  useUnfollowUser,
  getGetFollowersQueryKey,
  getGetFollowingQueryKey,
} from "@workspace/api-client-react";
import { useProfile, avatarUrl } from "@/context/ProfileContext";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users,
  UserPlus,
  UserCheck,
  UserMinus,
  Check,
  X,
  ArrowLeft,
  Eye,
  Bell,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { getGetSocialSummaryQueryKey } from "@workspace/api-client-react";

type Tab = "following" | "followers" | "friends" | "pending";

function UserAvatar({ avatarPath, username }: { avatarPath: string | null | undefined; username: string }) {
  const src = avatarUrl(avatarPath);
  if (src) {
    return (
      <img
        src={src}
        alt={username}
        className="w-10 h-10 rounded-full object-cover border border-border"
        onError={(e) => {
          (e.currentTarget as HTMLImageElement).style.display = "none";
        }}
      />
    );
  }
  return (
    <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
      <span className="text-sm font-bold text-primary">{username[0]?.toUpperCase() ?? "?"}</span>
    </div>
  );
}

export default function SettingsConnections() {
  const [tab, setTab] = useState<Tab>("following");
  const { profile } = useProfile();
  const { user } = useUser();
  const qc = useQueryClient();

  const { data: incomingData, isLoading: loadingIncoming } = useGetIncomingFriendRequests();
  const { data: outgoingData, isLoading: loadingOutgoing } = useGetOutgoingFriendRequests();
  const { data: friendsData, isLoading: loadingFriends } = useGetFriends();
  const followerSlug = profile?.slug ?? "";
  const { data: followersData, isLoading: loadingFollowers } = useGetFollowers(
    followerSlug,
    { query: { enabled: !!profile?.slug, queryKey: getGetFollowersQueryKey(followerSlug) } },
  );
  const { data: followingData, isLoading: loadingFollowing } = useGetFollowing(
    followerSlug,
    { query: { enabled: !!profile?.slug, queryKey: getGetFollowingQueryKey(followerSlug) } },
  );

  const respondMutation = useRespondToFriendRequest({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetSocialSummaryQueryKey() });
      },
    },
  });
  const cancelFriendMutation = useCancelOrRemoveFriendRequest({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetSocialSummaryQueryKey() });
      },
    },
  });
  const unfollowMutation = useUnfollowUser();

  const pendingCount = incomingData?.requests?.length ?? 0;

  const tabs: { id: Tab; label: string; icon: React.ElementType; count?: number }[] = [
    { id: "following", label: "Following", icon: Eye, count: followingData?.users?.length },
    { id: "followers", label: "Followers", icon: Users, count: followersData?.users?.length },
    { id: "friends", label: "Friends", icon: UserCheck, count: friendsData?.friends?.length },
    { id: "pending", label: "Requests", icon: Bell, count: pendingCount || undefined },
  ];

  return (
    <div className="max-w-2xl mx-auto w-full flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <Link href="/settings/profile">
          <Button variant="ghost" size="sm" className="font-mono text-muted-foreground gap-1">
            <ArrowLeft className="w-4 h-4" />
            Settings
          </Button>
        </Link>
      </div>

      <div className="flex items-center gap-3 border-b border-border/50 pb-4">
        <Users className="w-5 h-5 text-primary" />
        <h1 className="text-2xl font-bold uppercase tracking-tight">Connections</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border/50">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "px-4 py-2 text-sm font-mono uppercase tracking-wider flex items-center gap-2 border-b-2 -mb-px transition-colors",
              tab === t.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
            {t.count !== undefined && t.count > 0 && (
              <span
                className={cn(
                  "text-xs px-1.5 py-0.5 rounded-full font-bold",
                  tab === t.id
                    ? "bg-primary/20 text-primary"
                    : t.id === "pending"
                    ? "bg-destructive/20 text-destructive"
                    : "bg-secondary text-muted-foreground",
                )}
              >
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Following */}
      {tab === "following" && (
        <div className="flex flex-col gap-3">
          {loadingFollowing ? (
            <Skeleton className="h-16 w-full" />
          ) : followingData?.users?.length === 0 ? (
            <EmptyState
              icon={Eye}
              message="You're not following anyone yet."
              hint="Visit a builder's profile and hit Follow."
            />
          ) : (
            followingData?.users?.map((u) => (
              <UserRow key={u.userId} user={u}>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono text-xs gap-1 border-destructive/50 text-destructive hover:bg-destructive/10"
                  disabled={unfollowMutation.isPending}
                  onClick={() =>
                    unfollowMutation.mutate(
                      { slug: u.slug },
                      { onSuccess: () => qc.invalidateQueries() },
                    )
                  }
                >
                  <UserMinus className="w-3.5 h-3.5" />
                  Unfollow
                </Button>
              </UserRow>
            ))
          )}
        </div>
      )}

      {/* Followers */}
      {tab === "followers" && (
        <div className="flex flex-col gap-3">
          {loadingFollowers ? (
            <Skeleton className="h-16 w-full" />
          ) : followersData?.users?.length === 0 ? (
            <EmptyState
              icon={Users}
              message="No followers yet."
              hint="Share your builds to grow your following."
            />
          ) : (
            followersData?.users?.map((u) => (
              <UserRow key={u.userId} user={u} />
            ))
          )}
        </div>
      )}

      {/* Friends */}
      {tab === "friends" && (
        <div className="flex flex-col gap-3">
          {loadingFriends ? (
            <Skeleton className="h-16 w-full" />
          ) : friendsData?.friends?.length === 0 ? (
            <EmptyState
              icon={UserCheck}
              message="No friends yet."
              hint="Send friend requests from builder profiles."
            />
          ) : (
            friendsData?.friends?.map((f) => (
              <UserRow key={f.requestId} user={f.user}>
                <Button
                  variant="outline"
                  size="sm"
                  className="font-mono text-xs gap-1 border-destructive/50 text-destructive hover:bg-destructive/10"
                  disabled={cancelFriendMutation.isPending}
                  onClick={() =>
                    cancelFriendMutation.mutate(
                      { id: f.requestId },
                      { onSuccess: () => qc.invalidateQueries() },
                    )
                  }
                >
                  <UserMinus className="w-3.5 h-3.5" />
                  Remove
                </Button>
              </UserRow>
            ))
          )}

          {/* Outgoing pending */}
          {outgoingData?.requests && outgoingData.requests.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-3">
                Sent Requests
              </p>
              {outgoingData.requests.map((r) => (
                <UserRow key={r.id} user={r.receiver}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="font-mono text-xs gap-1 text-muted-foreground"
                    disabled={cancelFriendMutation.isPending}
                    onClick={() =>
                      cancelFriendMutation.mutate(
                        { id: r.id },
                        { onSuccess: () => qc.invalidateQueries() },
                      )
                    }
                  >
                    <X className="w-3.5 h-3.5" />
                    Cancel
                  </Button>
                </UserRow>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Pending requests */}
      {tab === "pending" && (
        <div className="flex flex-col gap-3">
          {loadingIncoming ? (
            <Skeleton className="h-16 w-full" />
          ) : incomingData?.requests?.length === 0 ? (
            <EmptyState
              icon={Bell}
              message="No pending requests."
              hint="When someone sends you a friend request it'll show up here."
            />
          ) : (
            incomingData?.requests?.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between p-3 rounded-sm border border-border/50 bg-secondary/20"
              >
                <Link href={`/u/${r.sender.slug}`} className="flex items-center gap-3 min-w-0">
                  <UserAvatar avatarPath={r.sender.avatarPath} username={r.sender.username} />
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">
                      {r.sender.displayName ?? r.sender.username}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono">
                      @{r.sender.username}
                    </p>
                  </div>
                </Link>
                <div className="flex gap-2 shrink-0">
                  <Button
                    size="sm"
                    className="font-mono text-xs gap-1 text-black"
                    disabled={respondMutation.isPending}
                    onClick={() =>
                      respondMutation.mutate(
                        { id: r.id, data: { action: "accept" } },
                        { onSuccess: () => qc.invalidateQueries() },
                      )
                    }
                  >
                    <Check className="w-3.5 h-3.5" />
                    Accept
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="font-mono text-xs gap-1 border-destructive/50 text-destructive hover:bg-destructive/10"
                    disabled={respondMutation.isPending}
                    onClick={() =>
                      respondMutation.mutate(
                        { id: r.id, data: { action: "decline" } },
                        { onSuccess: () => qc.invalidateQueries() },
                      )
                    }
                  >
                    <X className="w-3.5 h-3.5" />
                    Decline
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function UserRow({
  user,
  children,
}: {
  user: { userId: string; username: string; slug: string; displayName?: string | null | undefined; avatarPath?: string | null | undefined };
  children?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-sm border border-border/50 bg-secondary/20">
      <Link href={`/u/${user.slug}`} className="flex items-center gap-3 min-w-0">
        <UserAvatar avatarPath={user.avatarPath ?? null} username={user.username} />
        <div className="min-w-0">
          <p className="font-semibold text-sm truncate">
            {user.displayName ?? user.username}
          </p>
          <p className="text-xs text-muted-foreground font-mono">@{user.username}</p>
        </div>
      </Link>
      {children && <div className="shrink-0 ml-3">{children}</div>}
    </div>
  );
}

function EmptyState({
  icon: Icon,
  message,
  hint,
}: {
  icon: React.ElementType;
  message: string;
  hint: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center border border-dashed border-border/50 bg-secondary/10 rounded-sm">
      <Icon className="w-8 h-8 text-muted-foreground mb-3 opacity-40" />
      <p className="text-sm font-mono text-foreground mb-1">{message}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}
