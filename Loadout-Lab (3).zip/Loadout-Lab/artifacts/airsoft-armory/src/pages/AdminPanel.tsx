import { useEffect, useState, useCallback } from "react";
import { useUser } from "@clerk/react";
import { Link } from "wouter";
import { Crosshair, Users, Globe, LayoutDashboard, Trash2, Plus, ArrowLeft, ChevronDown, ChevronRight, Shield, Wrench, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatMoney, formatDate } from "@/lib/utils";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const api = (path: string) => `${BASE}/api${path}`;

type Tab = "dashboard" | "users" | "domains";

interface AdminStats {
  totalBuilds: number;
  totalUpgrades: number;
  totalDomains: number;
  totalUsersWithBuilds: number;
}

interface AdminUser {
  id: string;
  email: string | null;
  name: string;
  buildCount: number;
  joinedAt: string;
  isSuperAdmin: boolean;
}

interface UserBuild {
  id: number;
  gunName: string;
  category: string;
  totalCost: number;
  specialty: string | null;
  createdAt: string;
}

interface ApprovedDomain {
  id: number;
  domain: string;
  addedAt: string;
  addedBy: string;
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="bg-card border border-border rounded-sm p-5">
      <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">{label}</p>
      <p className="text-3xl font-bold text-primary font-mono">{value}</p>
    </div>
  );
}

function Dashboard({ stats }: { stats: AdminStats | null }) {
  if (!stats) return <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-24" />)}</div>;
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold font-mono uppercase tracking-widest">Overview</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Builds" value={stats.totalBuilds} />
        <StatCard label="Total Upgrades" value={stats.totalUpgrades} />
        <StatCard label="Active Builders" value={stats.totalUsersWithBuilds} />
        <StatCard label="Approved Domains" value={stats.totalDomains} />
      </div>
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [userBuilds, setUserBuilds] = useState<Record<string, UserBuild[]>>({});
  const [loadingBuilds, setLoadingBuilds] = useState<string | null>(null);

  useEffect(() => {
    fetch(api("/admin/users")).then(r => r.json()).then(setUsers).catch(() => setUsers([]));
  }, []);

  const toggleUser = async (userId: string) => {
    if (expanded === userId) { setExpanded(null); return; }
    setExpanded(userId);
    if (userBuilds[userId]) return;
    setLoadingBuilds(userId);
    try {
      const r = await fetch(api(`/admin/users/${userId}/builds`));
      const data = await r.json();
      setUserBuilds(prev => ({ ...prev, [userId]: data.builds }));
    } finally {
      setLoadingBuilds(null);
    }
  };

  if (!users) return <div className="space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>;
  if (users.length === 0) return (
    <div className="text-center py-12 border border-dashed border-border rounded-sm">
      <p className="text-muted-foreground font-mono text-sm">No users with builds yet</p>
    </div>
  );

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-bold font-mono uppercase tracking-widest">Users ({users.length})</h2>
      <div className="border border-border rounded-sm overflow-hidden">
        {users.map((user, i) => (
          <div key={user.id} className={cn("border-b border-border last:border-0", expanded === user.id && "bg-secondary/20")}>
            <button
              onClick={() => toggleUser(user.id)}
              className="w-full flex items-center gap-4 px-5 py-4 text-left hover:bg-secondary/30 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm truncate">{user.name}</span>
                  {user.isSuperAdmin && (
                    <Badge variant="outline" className="border-primary/50 text-primary bg-primary/10 text-[10px] shrink-0">
                      <Shield className="w-2.5 h-2.5 mr-1" /> Superadmin
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground font-mono mt-0.5 truncate">{user.email}</p>
              </div>
              <div className="flex items-center gap-4 shrink-0 text-sm font-mono">
                <span className="text-muted-foreground hidden sm:block">Joined {formatDate(user.joinedAt)}</span>
                <span className="text-primary font-bold">{user.buildCount} build{user.buildCount !== 1 ? "s" : ""}</span>
                {expanded === user.id ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
              </div>
            </button>

            {expanded === user.id && (
              <div className="px-5 pb-4 border-t border-border/50 bg-background/50">
                {loadingBuilds === user.id ? (
                  <div className="pt-4 space-y-2">{[...Array(2)].map((_, i) => <Skeleton key={i} className="h-10" />)}</div>
                ) : (userBuilds[user.id] ?? []).length === 0 ? (
                  <p className="pt-4 text-xs text-muted-foreground font-mono">No builds found</p>
                ) : (
                  <div className="pt-4 space-y-2">
                    {(userBuilds[user.id] ?? []).map(b => (
                      <Link key={b.id} href={`/builds/${b.id}`}>
                        <div className="flex items-center justify-between p-3 rounded-sm border border-border hover:border-primary/40 hover:bg-secondary/30 transition-colors cursor-pointer">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-medium truncate">{b.gunName}</span>
                              <Badge variant="outline" className="text-[10px] shrink-0 max-w-[120px] truncate">{b.category}</Badge>
                              {b.specialty && (
                                <span className="text-[10px] text-yellow-400 font-mono truncate hidden sm:block">{b.specialty}</span>
                              )}
                            </div>
                            <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{formatDate(b.createdAt)}</p>
                          </div>
                          <span className="text-primary font-mono font-bold text-sm shrink-0 ml-4">{formatMoney(b.totalCost)}</span>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function DomainsTab() {
  const [domains, setDomains] = useState<ApprovedDomain[] | null>(null);
  const [input, setInput] = useState("");
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    fetch(api("/admin/domains")).then(r => r.json()).then(setDomains).catch(() => setDomains([]));
  }, []);

  useEffect(() => { load(); }, [load]);

  const addDomain = async () => {
    if (!input.trim()) return;
    setAdding(true);
    setError(null);
    try {
      const r = await fetch(api("/admin/domains"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: input.trim() }),
      });
      if (!r.ok) {
        const d = await r.json();
        setError(d.error ?? "Failed to add domain");
      } else {
        setInput("");
        load();
      }
    } finally {
      setAdding(false);
    }
  };

  const removeDomain = async (id: number) => {
    await fetch(api(`/admin/domains/${id}`), { method: "DELETE" });
    load();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold font-mono uppercase tracking-widest">Approved Domains</h2>
        <p className="text-xs text-muted-foreground font-mono mt-1">
          When a user pastes a product URL from one of these domains, the app suggests the product's image automatically. Max 50 domains.
        </p>
      </div>

      {/* Add domain */}
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={e => { setInput(e.target.value); setError(null); }}
          placeholder="evike.com"
          className="font-mono max-w-xs"
          onKeyDown={e => e.key === "Enter" && addDomain()}
        />
        <Button onClick={addDomain} disabled={adding || !input.trim()} className="gap-2 font-mono uppercase tracking-wider shrink-0">
          <Plus className="w-4 h-4" />
          {adding ? "Adding..." : "Add Domain"}
        </Button>
      </div>
      {error && <p className="text-xs text-destructive font-mono">{error}</p>}

      {!domains ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
      ) : domains.length === 0 ? (
        <div className="text-center py-8 border border-dashed border-border rounded-sm">
          <Globe className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground font-mono">No approved domains yet</p>
        </div>
      ) : (
        <div className="border border-border rounded-sm overflow-hidden">
          {domains.map((d, i) => (
            <div key={d.id} className="flex items-center justify-between px-5 py-3 border-b border-border last:border-0 hover:bg-secondary/20 transition-colors">
              <div>
                <span className="font-mono text-sm text-foreground">{d.domain}</span>
                <p className="text-[10px] text-muted-foreground font-mono mt-0.5">Added {formatDate(d.addedAt)}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                onClick={() => removeDomain(d.id)}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminPanel() {
  const { user, isLoaded } = useUser();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [stats, setStats] = useState<AdminStats | null>(null);

  useEffect(() => {
    if (!isLoaded) return;
    if (!user) { setAuthorized(false); return; }
    fetch(api("/admin/me"))
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(() => {
        setAuthorized(true);
        return fetch(api("/admin/stats"));
      })
      .then(r => r.json())
      .then(setStats)
      .catch(() => setAuthorized(false));
  }, [isLoaded, user]);

  if (!isLoaded || authorized === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-2">
          <Crosshair className="w-8 h-8 text-primary mx-auto animate-spin" />
          <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Authenticating…</p>
        </div>
      </div>
    );
  }

  if (!authorized) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Shield className="w-12 h-12 text-destructive mx-auto" />
          <h1 className="text-xl font-bold">Access Denied</h1>
          <p className="text-sm text-muted-foreground font-mono">This terminal is restricted.</p>
          <Link href="/feed"><Button variant="outline" className="gap-2 font-mono"><ArrowLeft className="w-4 h-4" /> Back to Feed</Button></Link>
        </div>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "users", label: "Users", icon: Users },
    { id: "domains", label: "Domains", icon: Globe },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto max-w-6xl px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Crosshair className="w-5 h-5 text-primary" />
            <span className="font-mono text-sm uppercase tracking-widest text-foreground">
              Airsoft<span className="text-primary">Armory</span> <span className="text-muted-foreground">// Ops Terminal</span>
            </span>
          </div>
          <Link href="/feed">
            <Button variant="ghost" size="sm" className="font-mono text-xs gap-2 text-muted-foreground">
              <ArrowLeft className="w-3.5 h-3.5" /> Exit
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* Tab nav */}
        <div className="flex gap-1 border-b border-border mb-8 overflow-x-auto">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-xs font-mono uppercase tracking-widest border-b-2 -mb-px transition-colors whitespace-nowrap",
                tab === t.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              <t.icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          ))}
        </div>

        {tab === "dashboard" && <Dashboard stats={stats} />}
        {tab === "users" && <UsersTab />}
        {tab === "domains" && <DomainsTab />}
      </div>
    </div>
  );
}
