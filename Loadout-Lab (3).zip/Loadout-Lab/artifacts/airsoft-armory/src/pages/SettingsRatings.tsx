import { useGetMyRatings, useRemoveRating, getGetMyRatingsQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Star, Trash2, ArrowLeft, Crosshair } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatMoney, formatDate } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function SettingsRatings() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useGetMyRatings();

  const removeMutation = useRemoveRating({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMyRatingsQueryKey() });
      },
    },
  });

  if (isLoading) {
    return (
      <div className="w-full max-w-3xl mx-auto space-y-4">
        <Skeleton className="h-8 w-48" />
        {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
      </div>
    );
  }

  const ratings = data?.ratings ?? [];

  return (
    <div className="w-full max-w-3xl mx-auto flex flex-col gap-6 pb-12">
      {/* Header */}
      <div className="flex items-center gap-4 border-b border-border/50 pb-4">
        <Link href="/settings/profile">
          <Button variant="ghost" size="sm" className="font-mono text-muted-foreground gap-2">
            <ArrowLeft className="w-4 h-4" /> Settings
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Star className="w-5 h-5 text-yellow-400" />
          <h1 className="text-xl font-bold tracking-tight">My Ratings</h1>
          {ratings.length > 0 && (
            <Badge variant="outline" className="font-mono text-xs border-yellow-500/30 text-yellow-400">
              {ratings.length}
            </Badge>
          )}
        </div>
      </div>

      {ratings.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-border/50 rounded-sm bg-secondary/10">
          <Star className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
          <p className="font-mono text-sm text-muted-foreground uppercase tracking-widest mb-1">No ratings yet</p>
          <p className="text-xs text-muted-foreground/60 mb-6">Rate builds you've reviewed to keep track of your favorites</p>
          <Link href="/feed">
            <Button variant="outline" size="sm" className="font-mono uppercase tracking-widest gap-2">
              <Crosshair className="w-3.5 h-3.5" /> Browse Builds
            </Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {ratings.map((r) => (
            <div
              key={r.id}
              className="flex items-center gap-4 p-4 border border-border bg-card/50 rounded-sm hover:border-border/80 transition-colors group"
            >
              {/* Stars */}
              <div className="flex items-center gap-0.5 shrink-0">
                {[1, 2, 3, 4, 5].map((v) => (
                  <Star
                    key={v}
                    className={`w-4 h-4 ${v <= r.myRating ? "fill-yellow-400 text-yellow-400" : "fill-none text-muted-foreground/30"}`}
                  />
                ))}
              </div>

              {/* Build info */}
              <div className="flex-1 min-w-0">
                <Link href={`/builds/${r.id}`}>
                  <p className="font-semibold text-foreground hover:text-primary transition-colors truncate">
                    {r.gunName}
                  </p>
                </Link>
                <p className="text-xs font-mono text-muted-foreground truncate">
                  {r.category} · {r.authorName} · rated {formatDate(r.ratedAt)}
                </p>
              </div>

              {/* Cost */}
              <span className="shrink-0 text-sm font-mono text-primary font-bold">
                {formatMoney(r.totalCost)}
              </span>

              {/* Remove */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeMutation.mutate({ id: r.id })}
                disabled={removeMutation.isPending}
                className="shrink-0 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Remove rating"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
