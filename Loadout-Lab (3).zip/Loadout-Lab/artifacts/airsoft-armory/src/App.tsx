import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk, useUser, useAuth } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from 'wouter';
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/Layout";
import { ProfileProvider, useProfile } from "@/context/ProfileContext";
import { Crosshair } from "lucide-react";

// Pages
import Home from "./pages/Home";
import Feed from "./pages/Feed";
import Search from "./pages/Search";
import PostBuild from "./pages/PostBuild";
import BuildDetail from "./pages/BuildDetail";
import MyBuilds from "./pages/MyBuilds";
import AdminPanel from "./pages/AdminPanel";
import SetupUsername from "./pages/SetupUsername";
import ProfilePage from "./pages/ProfilePage";
import ProfileSettings from "./pages/ProfileSettings";
import SettingsRatings from "./pages/SettingsRatings";
import SettingsFavorites from "./pages/SettingsFavorites";
import SettingsConnections from "./pages/SettingsConnections";
import NotFound from "./pages/not-found";

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(24 100% 50%)",
    colorForeground: "hsl(220 10% 90%)",
    colorMutedForeground: "hsl(220 10% 60%)",
    colorDanger: "hsl(0 80% 50%)",
    colorBackground: "hsl(220 10% 11%)",
    colorInput: "hsl(220 10% 15%)",
    colorInputForeground: "hsl(220 10% 90%)",
    colorNeutral: "hsl(220 10% 20%)",
    fontFamily: "Geist, sans-serif",
    borderRadius: "2px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-card border-card-border rounded-sm w-[440px] max-w-full overflow-hidden shadow-2xl shadow-primary/10",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-sans font-bold",
    headerSubtitle: "text-muted-foreground font-mono text-xs uppercase",
    socialButtonsBlockButtonText: "text-foreground font-mono text-xs uppercase",
    formFieldLabel: "text-muted-foreground font-mono text-xs uppercase",
    footerActionLink: "text-primary hover:text-primary/80 font-mono text-xs uppercase",
    footerActionText: "text-muted-foreground font-mono text-xs",
    dividerText: "text-muted-foreground font-mono text-xs bg-card px-2",
    identityPreviewEditButton: "text-primary hover:text-primary/80",
    formFieldSuccessText: "text-primary",
    alertText: "text-destructive",
    logoBox: "mb-4",
    logoImage: "h-12 w-auto filter drop-shadow-[0_0_8px_rgba(249,115,22,0.5)]",
    socialButtonsBlockButton: "border-border bg-secondary hover:bg-secondary/80 rounded-sm",
    formButtonPrimary: "bg-primary text-primary-foreground hover:bg-primary/90 font-mono uppercase tracking-widest rounded-sm shadow-[0_0_15px_rgba(249,115,22,0.3)]",
    formFieldInput: "bg-input border-border text-foreground font-mono rounded-sm focus:ring-1 focus:ring-primary",
    footerAction: "bg-secondary/30 py-4 border-t border-border",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border border-destructive/30 rounded-sm",
    otpCodeFieldInput: "bg-input border-border text-foreground rounded-sm",
    formFieldRow: "mb-4",
    main: "p-8",
  },
};

function FullPageLoader() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-background">
      <Crosshair className="w-8 h-8 text-primary animate-spin" />
    </div>
  );
}

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.05)_0,transparent_50%)]" />
      <div className="w-full max-w-[440px]">
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
      </div>
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.05)_0,transparent_50%)]" />
      <div className="w-full max-w-[440px]">
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      </div>
    </div>
  );
}

/** Registers Clerk's getToken with the shared API client so every generated
 *  hook and customFetch call includes an Authorization: Bearer <token> header. */
function ClerkAuthTokenRegistrar() {
  const { getToken } = useAuth();
  useEffect(() => {
    setAuthTokenGetter(() => getToken());
    return () => setAuthTokenGetter(null);
  }, [getToken]);
  return null;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/feed" />
      </Show>
      <Show when="signed-out">
        <Home />
      </Show>
    </>
  );
}

/** Requires Clerk auth AND a completed profile setup */
function ProfileGatedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoaded } = useUser();
  const { isLoading: profileLoading, hasProfile } = useProfile();

  if (!isLoaded || (user && profileLoading)) return <FullPageLoader />;
  if (!user) return <Redirect to="/sign-in" />;
  if (!hasProfile) return <Redirect to="/setup/username" />;
  return <Component />;
}

/** Only Clerk auth — no profile required (used for setup page itself) */
function AuthOnlyRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <>
      <Show when="signed-in">
        <Component />
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Terminal Access",
            subtitle: "Authenticate to proceed",
          },
        },
        signUp: {
          start: {
            title: "New Operator",
            subtitle: "Initialize your profile",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ProfileProvider>
          <ClerkAuthTokenRegistrar />
          <ClerkQueryClientCacheInvalidator />
          <Switch>
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />

            {/* Username setup gate — auth required, no profile needed */}
            <Route path="/setup/username">
              <AuthOnlyRoute component={SetupUsername} />
            </Route>

            <Route path="/">
              <Layout>
                <HomeRedirect />
              </Layout>
            </Route>

            {/* Feed is public — anyone can browse */}
            <Route path="/feed">
              <Layout>
                <Feed />
              </Layout>
            </Route>

            <Route path="/search">
              <Layout>
                <Search />
              </Layout>
            </Route>

            {/* Build detail is public */}
            <Route path="/builds/:id">
              <Layout>
                <BuildDetail />
              </Layout>
            </Route>

            {/* Public profile page */}
            <Route path="/u/:slug">
              <Layout>
                <ProfilePage />
              </Layout>
            </Route>

            {/* Protected routes — need auth + profile */}
            <Route path="/post">
              <Layout>
                <ProfileGatedRoute component={PostBuild} />
              </Layout>
            </Route>

            <Route path="/my-builds">
              <Layout>
                <ProfileGatedRoute component={MyBuilds} />
              </Layout>
            </Route>

            <Route path="/settings/profile">
              <Layout>
                <ProfileGatedRoute component={ProfileSettings} />
              </Layout>
            </Route>

            <Route path="/settings/ratings">
              <Layout>
                <ProfileGatedRoute component={SettingsRatings} />
              </Layout>
            </Route>

            <Route path="/settings/favorites">
              <Layout>
                <ProfileGatedRoute component={SettingsFavorites} />
              </Layout>
            </Route>

            <Route path="/settings/connections">
              <Layout>
                <ProfileGatedRoute component={SettingsConnections} />
              </Layout>
            </Route>

            {/* Admin panel — not linked in nav */}
            <Route path="/armory-ops">
              <AdminPanel />
            </Route>
            <Route path="/armory-ops/*">
              <AdminPanel />
            </Route>

            <Route>
              <Layout>
                <NotFound />
              </Layout>
            </Route>
          </Switch>
        </ProfileProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
