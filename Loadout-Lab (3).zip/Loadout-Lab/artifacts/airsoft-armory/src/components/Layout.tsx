import { Link, useLocation } from "wouter";
import { Show, useClerk, useUser } from "@clerk/react";
import { Button } from "./ui/button";
import { Crosshair, Plus, Search, LogOut, LayoutDashboard, Menu, X, User, Users } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useProfile, avatarUrl } from "@/context/ProfileContext";
import { useGetSocialSummary, getGetSocialSummaryQueryKey } from "@workspace/api-client-react";

function PendingBadge() {
  const { isSignedIn } = useUser();
  const { data } = useGetSocialSummary({
    query: {
      enabled: !!isSignedIn,
      refetchInterval: 30_000,
      queryKey: getGetSocialSummaryQueryKey(),
    },
  });
  const count = data?.pendingFriendRequests ?? 0;
  if (!count) return null;
  return (
    <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-0.5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center leading-none">
      {count > 9 ? "9+" : count}
    </span>
  );
}

function UserAvatar() {
  const { profile } = useProfile();
  const imgSrc = avatarUrl(profile?.avatarPath);
  const initial = profile?.username?.[0]?.toUpperCase() ?? "?";

  if (imgSrc) {
    return (
      <img
        src={imgSrc}
        alt={profile?.username}
        className="w-7 h-7 rounded-full object-cover border border-border"
        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
      />
    );
  }
  return (
    <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
      <span className="text-xs font-bold text-primary">{initial}</span>
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const { profile } = useProfile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  const navItems = [
    { href: "/feed", label: "Feed", icon: LayoutDashboard },
    { href: "/search", label: "Database", icon: Search },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/30">
      <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity">
            <Crosshair className="w-6 h-6" />
            <span className="font-bold text-lg tracking-widest uppercase mt-0.5 text-foreground">
              Airsoft<span className="text-primary">Armory</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "text-sm font-mono uppercase tracking-wider flex items-center gap-2 px-3 py-2 rounded-sm transition-colors",
                  location === item.href
                    ? "bg-secondary text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            ))}

            <Show when="signed-in">
              <Link href="/my-builds" className={cn(
                "text-sm font-mono uppercase tracking-wider flex items-center gap-2 px-3 py-2 rounded-sm transition-colors",
                location === "/my-builds"
                  ? "bg-secondary text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}>
                <User className="w-4 h-4" />
                My Armory
              </Link>
              <Link href="/settings/connections" className={cn(
                "relative text-sm font-mono uppercase tracking-wider flex items-center gap-2 px-3 py-2 rounded-sm transition-colors",
                location === "/settings/connections"
                  ? "bg-secondary text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}>
                <span className="relative">
                  <Users className="w-4 h-4" />
                  <PendingBadge />
                </span>
                Connections
              </Link>
            </Show>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Show when="signed-out">
              <Link href="/sign-in" className="text-sm font-mono text-muted-foreground hover:text-foreground uppercase tracking-widest px-4 py-2">
                Login
              </Link>
              <Link href="/sign-up">
                <Button variant="default" size="sm" className="font-mono uppercase tracking-wider">
                  Deploy
                </Button>
              </Link>
            </Show>

            <Show when="signed-in">
              <Link href="/post">
                <Button variant="outline" size="sm" className="font-mono uppercase tracking-wider border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground gap-2">
                  <Plus className="w-4 h-4" />
                  Add Build
                </Button>
              </Link>

              {/* User avatar → profile settings */}
              <Link
                href={profile ? `/u/${profile.slug}` : "/settings/profile"}
                className="flex items-center gap-2 px-2 py-1 rounded-sm hover:bg-secondary/50 transition-colors"
              >
                <UserAvatar />
                {profile && (
                  <span className="text-xs font-mono text-muted-foreground hidden lg:block">
                    @{profile.username}
                  </span>
                )}
              </Link>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => signOut({ redirectUrl: basePath || "/" })}
                className="font-mono uppercase tracking-wider text-muted-foreground hover:text-destructive hover:bg-destructive/10 gap-2"
              >
                <LogOut className="w-4 h-4" />
                Evac
              </Button>
            </Show>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Nav */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-border bg-secondary/50">
          <div className="flex flex-col p-4 gap-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm font-mono uppercase tracking-wider flex items-center gap-2 p-3 rounded-sm text-foreground hover:bg-secondary"
              >
                <item.icon className="w-4 h-4 text-primary" />
                {item.label}
              </Link>
            ))}
            <Show when="signed-in">
              {profile && (
                <Link href={`/u/${profile.slug}`} onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2 p-3 rounded-sm text-foreground hover:bg-secondary">
                  <UserAvatar />
                  <span className="text-sm font-mono uppercase tracking-wider">@{profile.username}</span>
                </Link>
              )}
              <Link href="/my-builds" onClick={() => setMobileMenuOpen(false)} className="text-sm font-mono uppercase tracking-wider flex items-center gap-2 p-3 rounded-sm text-foreground hover:bg-secondary">
                <User className="w-4 h-4 text-primary" />
                My Armory
              </Link>
              <Link href="/settings/connections" onClick={() => setMobileMenuOpen(false)} className="text-sm font-mono uppercase tracking-wider flex items-center gap-2 p-3 rounded-sm text-foreground hover:bg-secondary">
                <span className="relative">
                  <Users className="w-4 h-4 text-primary" />
                  <PendingBadge />
                </span>
                Connections
              </Link>
              <Link href="/post" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="outline" className="w-full mt-2 font-mono uppercase tracking-wider border-primary text-primary justify-start gap-2">
                  <Plus className="w-4 h-4" />
                  Add Build
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={() => {
                  setMobileMenuOpen(false);
                  signOut({ redirectUrl: basePath || "/" });
                }}
                className="w-full mt-2 font-mono uppercase tracking-wider text-destructive justify-start gap-2 hover:bg-destructive/10 hover:text-destructive"
              >
                <LogOut className="w-4 h-4" />
                Evac
              </Button>
            </Show>
            <Show when="signed-out">
              <div className="flex gap-2 mt-2">
                <Link href="/sign-in" className="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" className="w-full font-mono uppercase">Login</Button>
                </Link>
                <Link href="/sign-up" className="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full font-mono uppercase text-black">Deploy</Button>
                </Link>
              </div>
            </Show>
          </div>
        </div>
      )}

      <main className="flex-1 flex flex-col w-full container mx-auto max-w-6xl px-4 py-8">
        {children}
      </main>

      <footer className="border-t border-border/50 py-8 bg-secondary/20 mt-auto">
        <div className="container mx-auto max-w-6xl px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 opacity-50">
            <Crosshair className="w-5 h-5" />
            <span className="font-mono text-sm tracking-widest uppercase">Airsoft Armory // Terminal</span>
          </div>
          <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest">
            Tactical build database
          </p>
        </div>
      </footer>
    </div>
  );
}
