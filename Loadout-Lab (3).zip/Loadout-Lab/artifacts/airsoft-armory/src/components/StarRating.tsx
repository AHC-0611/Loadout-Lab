/**
 * StarRating — interactive (auth) or display-only (guest).
 *
 * Props:
 *  averageRating  – aggregate average (null = no ratings yet)
 *  ratingCount    – total number of ratings
 *  myRating       – authenticated user's current rating (null = none)
 *  onRate         – called with new value 1-5; if undefined the widget is read-only
 *  onRemove       – called when user clicks their active star to remove rating
 *  isPending      – show loading state while mutation is in flight
 */

import { useState } from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  averageRating?: number | null;
  ratingCount?: number;
  myRating?: number | null;
  onRate?: (value: number) => void;
  onRemove?: () => void;
  isPending?: boolean;
  size?: "sm" | "md";
}

export function StarRating({
  averageRating,
  ratingCount = 0,
  myRating,
  onRate,
  onRemove,
  isPending,
  size = "md",
}: StarRatingProps) {
  const [hovered, setHovered] = useState<number | null>(null);

  const iconSize = size === "sm" ? "w-3.5 h-3.5" : "w-5 h-5";
  const interactive = !!onRate;

  const displayValue = hovered ?? myRating ?? 0;

  return (
    <div className="flex flex-col gap-1.5">
      <div
        className={cn("flex items-center gap-0.5", isPending && "opacity-50 pointer-events-none")}
        onMouseLeave={() => interactive && setHovered(null)}
      >
        {[1, 2, 3, 4, 5].map((v) => (
          <button
            key={v}
            type="button"
            disabled={!interactive || isPending}
            onClick={() => {
              if (!interactive) return;
              if (myRating === v) {
                onRemove?.();
              } else {
                onRate?.(v);
              }
            }}
            onMouseEnter={() => interactive && setHovered(v)}
            className={cn(
              "transition-colors focus-visible:outline-none",
              interactive
                ? "cursor-pointer hover:scale-110 transition-transform"
                : "cursor-default",
            )}
            aria-label={`Rate ${v} star${v !== 1 ? "s" : ""}`}
          >
            <Star
              className={cn(
                iconSize,
                "transition-colors",
                v <= displayValue
                  ? "fill-yellow-400 text-yellow-400"
                  : "fill-none text-muted-foreground/40",
              )}
            />
          </button>
        ))}
      </div>

      <div className="text-xs font-mono text-muted-foreground flex items-center gap-1.5">
        {ratingCount > 0 ? (
          <>
            <span className="text-yellow-400 font-semibold">
              {averageRating?.toFixed(1) ?? "—"}
            </span>
            <span>avg · {ratingCount} rating{ratingCount !== 1 ? "s" : ""}</span>
          </>
        ) : (
          <span>No ratings yet</span>
        )}
        {myRating != null && (
          <span className="text-primary/70 ml-1">· you: {myRating}★</span>
        )}
      </div>
    </div>
  );
}

/** Compact read-only star badge for feed cards */
export function StarBadge({
  averageRating,
  ratingCount = 0,
}: {
  averageRating?: number | null;
  ratingCount?: number;
}) {
  if (ratingCount === 0) {
    return (
      <span className="flex items-center gap-0.5 text-[10px] font-mono text-muted-foreground/50">
        <Star className="w-3 h-3" />
        <span>—</span>
      </span>
    );
  }
  return (
    <span className="flex items-center gap-0.5 text-[10px] font-mono text-yellow-400">
      <Star className="w-3 h-3 fill-yellow-400" />
      <span className="font-semibold">{averageRating?.toFixed(1)}</span>
      <span className="text-muted-foreground/60">({ratingCount})</span>
    </span>
  );
}
