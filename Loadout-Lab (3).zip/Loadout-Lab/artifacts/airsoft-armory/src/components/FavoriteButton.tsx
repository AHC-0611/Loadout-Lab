/**
 * FavoriteButton — heart toggle.
 * Shows a sign-in nudge for unauthenticated users.
 */

import { useState } from "react";
import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser } from "@clerk/react";
import { Link } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface FavoriteButtonProps {
  favorited: boolean;
  favoriteCount?: number;
  onToggle?: () => void;
  isPending?: boolean;
  size?: "sm" | "md";
  showCount?: boolean;
}

export function FavoriteButton({
  favorited,
  favoriteCount = 0,
  onToggle,
  isPending,
  size = "md",
  showCount = false,
}: FavoriteButtonProps) {
  const { isSignedIn } = useUser();
  const [nudge, setNudge] = useState(false);

  const iconSize = size === "sm" ? "w-3.5 h-3.5" : "w-5 h-5";

  function handleClick(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!isSignedIn) {
      setNudge(true);
      setTimeout(() => setNudge(false), 2500);
      return;
    }
    onToggle?.();
  }

  return (
    <div className="relative inline-flex items-center">
      <button
        type="button"
        onClick={handleClick}
        disabled={isPending}
        className={cn(
          "flex items-center gap-1 transition-all focus-visible:outline-none",
          isPending && "opacity-50 pointer-events-none",
          favorited
            ? "text-red-500 hover:text-red-400"
            : "text-muted-foreground/50 hover:text-red-400",
        )}
        aria-label={favorited ? "Remove from favorites" : "Add to favorites"}
      >
        <Heart
          className={cn(
            iconSize,
            "transition-all duration-200",
            favorited ? "fill-red-500 scale-110" : "fill-none",
          )}
        />
        {showCount && (
          <span className="text-[10px] font-mono tabular-nums">
            {favoriteCount > 0 ? favoriteCount : ""}
          </span>
        )}
      </button>

      {/* Sign-in nudge tooltip */}
      {nudge && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 pointer-events-auto">
          <div className="bg-card border border-border rounded-sm px-3 py-2 text-xs font-mono text-foreground whitespace-nowrap shadow-xl">
            <Link
              href={`${BASE}/sign-in`}
              className="text-primary hover:underline"
              onClick={(e) => e.stopPropagation()}
            >
              Sign in
            </Link>{" "}
            to save builds
          </div>
        </div>
      )}
    </div>
  );
}
