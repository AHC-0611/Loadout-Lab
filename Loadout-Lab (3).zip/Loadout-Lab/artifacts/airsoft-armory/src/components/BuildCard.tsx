import type { Build } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "./ui/card";
import { Badge } from "./ui/badge";
import { formatMoney, formatDate } from "@/lib/utils";
import { Link } from "wouter";
import { Crosshair, User, Calendar, DollarSign, Zap, Camera } from "lucide-react";
import { StarBadge } from "./StarRating";
import { FavoriteButton } from "./FavoriteButton";
import {
  useToggleFavorite,
  getListBuildsQueryKey,
  getGetMyFavoritesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function gunImageUrl(path: string | null | undefined) {
  if (!path) return null;
  return `${BASE}/api/storage${path}`;
}

export function BuildCard({ build }: { build: Build }) {
  const imgUrl = gunImageUrl(build.gunImagePath);
  const queryClient = useQueryClient();

  const toggleMutation = useToggleFavorite({
    mutation: {
      onSuccess: (data) => {
        // Optimistically update this card in the builds list cache
        queryClient.setQueriesData(
          { queryKey: getListBuildsQueryKey() },
          (old: any) => {
            if (!old?.builds) return old;
            return {
              ...old,
              builds: old.builds.map((b: Build) =>
                b.id === build.id
                  ? { ...b, isFavorited: data.favorited, favoriteCount: data.favoriteCount }
                  : b,
              ),
            };
          },
        );
        queryClient.invalidateQueries({ queryKey: getGetMyFavoritesQueryKey() });
      },
    },
  });

  return (
    <Link href={`/builds/${build.id}`} className="block h-full hover:no-underline group">
      <Card className="h-full transition-all duration-200 hover:border-primary/50 hover:shadow-[0_0_20px_rgba(249,115,22,0.1)] flex flex-col overflow-hidden">

        {/* Gun photo banner */}
        {imgUrl ? (
          <div className="w-full h-40 overflow-hidden bg-secondary/30 border-b border-border/50 shrink-0">
            <img
              src={imgUrl}
              alt={build.gunName}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              onError={(e) => { (e.currentTarget.parentElement as HTMLElement).style.display = "none"; }}
            />
          </div>
        ) : (
          <div className="w-full h-24 overflow-hidden bg-secondary/10 border-b border-border/30 shrink-0 flex items-center justify-center">
            <Camera className="w-7 h-7 text-muted-foreground/20" />
          </div>
        )}

        <CardHeader className="pb-3 pt-4">
          <div className="flex justify-between items-start gap-3">
            <CardTitle className="text-base font-bold text-foreground group-hover:text-primary transition-colors flex items-center gap-2 min-w-0">
              <Crosshair className="w-4 h-4 text-primary shrink-0" />
              <span className="truncate">{build.gunName}</span>
            </CardTitle>
            <Badge variant="outline" className="shrink-0 border-primary/30 text-primary bg-primary/5 text-xs max-w-[120px] truncate">
              {build.category}
            </Badge>
          </div>

          {/* Author — clickable if they have a profile slug */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-mono text-muted-foreground mt-1">
            <span className="flex items-center gap-1">
              <User className="w-3 h-3 shrink-0" />
              {build.authorSlug ? (
                <Link
                  href={`/u/${build.authorSlug}`}
                  className="hover:text-primary transition-colors"
                  onClick={(e) => e.stopPropagation()}
                >
                  {build.authorName}
                </Link>
              ) : (
                <span>{build.authorName}</span>
              )}
            </span>
            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{formatDate(build.createdAt)}</span>
          </div>

          {build.specialty && (
            <Badge variant="outline" className="mt-1.5 border-yellow-500/40 text-yellow-400 bg-yellow-500/10 text-[10px] flex items-center gap-1 w-fit max-w-full truncate">
              <Zap className="w-2.5 h-2.5 shrink-0" />
              <span className="truncate">{build.specialty}</span>
            </Badge>
          )}
        </CardHeader>

        <CardContent className="flex-grow pt-0">
          <p className="text-sm text-foreground/80 line-clamp-2 leading-relaxed">
            {build.description || "No description provided."}
          </p>
        </CardContent>

        <CardFooter className="pt-3 border-t border-border/50 flex justify-between items-center bg-secondary/10">
          <div className="flex flex-col gap-0.5 min-w-0">
            <div className="flex items-center gap-1 text-primary font-mono font-bold">
              <DollarSign className="w-3.5 h-3.5 shrink-0" />
              <span className="text-base">{formatMoney(build.totalCost).replace("$", "")}</span>
              <span className="text-[10px] text-muted-foreground font-normal ml-0.5">upgrades</span>
            </div>
            {build.baseCost != null && (
              <span className="text-[10px] font-mono text-muted-foreground truncate">
                gun: {formatMoney(build.baseCost)}
              </span>
            )}
          </div>

          {/* Engagement: stars + favorite */}
          <div className="flex items-center gap-3 shrink-0">
            <StarBadge
              averageRating={build.averageRating}
              ratingCount={build.ratingCount}
            />
            <FavoriteButton
              favorited={build.isFavorited}
              favoriteCount={build.favoriteCount}
              showCount
              size="sm"
              onToggle={() => toggleMutation.mutate({ id: build.id })}
              isPending={toggleMutation.isPending}
            />
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
