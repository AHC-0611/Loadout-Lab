/**
 * Follow / Friend-Request buttons shown on a public profile page.
 * Receives the current viewer state and fires API mutations on click.
 */
import { useState } from "react";
import { useUser } from "@clerk/react";
import { Link } from "wouter";
import {
  useFollowUser,
  useUnfollowUser,
  useSendFriendRequest,
  useRespondToFriendRequest,
  useCancelOrRemoveFriendRequest,
  getGetPublicProfileQueryKey,
  getGetSocialSummaryQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck, UserMinus, UserX, Eye, EyeOff, Clock } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

interface SocialButtonsProps {
  slug: string;
  isFollowing: boolean;
  isMutual: boolean;
  friendshipStatus: "none" | "pending_sent" | "pending_received" | "friends";
  friendRequestId?: number | null;
}

export function SocialButtons({
  slug,
  isFollowing,
  isMutual,
  friendshipStatus,
  friendRequestId,
}: SocialButtonsProps) {
  const { isSignedIn } = useUser();
  const qc = useQueryClient();

  const followMutation = useFollowUser();
  const unfollowMutation = useUnfollowUser();
  const friendRequestMutation = useSendFriendRequest();
  const respondMutation = useRespondToFriendRequest();
  const cancelMutation = useCancelOrRemoveFriendRequest();

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getGetPublicProfileQueryKey(slug) });
    qc.invalidateQueries({ queryKey: getGetSocialSummaryQueryKey() });
  };

  if (!isSignedIn) {
    return (
      <Link href="/sign-in">
        <Button variant="outline" size="sm" className="font-mono text-xs gap-1">
          <UserPlus className="w-4 h-4" />
          Follow
        </Button>
      </Link>
    );
  }

  const isFollowLoading = followMutation.isPending || unfollowMutation.isPending;
  const isFriendLoading =
    friendRequestMutation.isPending || respondMutation.isPending || cancelMutation.isPending;

  return (
    <div className="flex gap-2 flex-wrap">
      {/* Follow / Unfollow */}
      {isFollowing ? (
        <Button
          variant="outline"
          size="sm"
          className="font-mono text-xs gap-1 border-border text-muted-foreground hover:border-destructive/50 hover:text-destructive"
          disabled={isFollowLoading}
          onClick={() => unfollowMutation.mutate({ slug }, { onSuccess: invalidate })}
        >
          {isMutual ? (
            <UserCheck className="w-4 h-4 text-primary" />
          ) : (
            <EyeOff className="w-4 h-4" />
          )}
          {isMutual ? "Mutual" : "Unfollow"}
        </Button>
      ) : (
        <Button
          variant="outline"
          size="sm"
          className="font-mono text-xs gap-1 border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
          disabled={isFollowLoading}
          onClick={() => followMutation.mutate({ slug }, { onSuccess: invalidate })}
        >
          <Eye className="w-4 h-4" />
          Follow
        </Button>
      )}

      {/* Friend button */}
      {friendshipStatus === "none" && (
        <Button
          variant="ghost"
          size="sm"
          className="font-mono text-xs gap-1 text-muted-foreground hover:text-foreground"
          disabled={isFriendLoading}
          onClick={() => friendRequestMutation.mutate({ slug }, { onSuccess: invalidate })}
        >
          <UserPlus className="w-4 h-4" />
          Add Friend
        </Button>
      )}

      {friendshipStatus === "pending_sent" && (
        <Button
          variant="ghost"
          size="sm"
          className="font-mono text-xs gap-1 text-muted-foreground"
          disabled={isFriendLoading}
          onClick={() =>
            friendRequestId != null &&
            cancelMutation.mutate({ id: friendRequestId }, { onSuccess: invalidate })
          }
        >
          <Clock className="w-4 h-4" />
          Pending…
        </Button>
      )}

      {friendshipStatus === "pending_received" && (
        <div className="flex gap-1">
          <Button
            size="sm"
            className="font-mono text-xs gap-1 text-black"
            disabled={isFriendLoading}
            onClick={() =>
              friendRequestId != null &&
              respondMutation.mutate(
                { id: friendRequestId, data: { action: "accept" } },
                { onSuccess: invalidate },
              )
            }
          >
            <UserCheck className="w-4 h-4" />
            Accept
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="font-mono text-xs gap-1 text-muted-foreground"
            disabled={isFriendLoading}
            onClick={() =>
              friendRequestId != null &&
              respondMutation.mutate(
                { id: friendRequestId, data: { action: "decline" } },
                { onSuccess: invalidate },
              )
            }
          >
            <UserX className="w-4 h-4" />
            Decline
          </Button>
        </div>
      )}

      {friendshipStatus === "friends" && (
        <Button
          variant="ghost"
          size="sm"
          className="font-mono text-xs gap-1 text-primary cursor-default"
          disabled
        >
          <UserCheck className="w-4 h-4" />
          Friends
        </Button>
      )}
    </div>
  );
}
