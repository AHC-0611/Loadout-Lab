import { Router, type IRouter } from "express";
import { getAuth, clerkClient } from "@clerk/express";
import { db, buildsTable, upgradesTable, approvedDomainsTable } from "@workspace/db";
import { eq, count, desc } from "drizzle-orm";

const router: IRouter = Router();

// ─── Middleware ────────────────────────────────────────────────────────────────

async function requireSuperAdmin(req: any, res: any, next: any): Promise<void> {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  try {
    const user = await clerkClient.users.getUser(userId);
    const email = user.emailAddresses.find(
      (e: any) => e.id === user.primaryEmailAddressId,
    )?.emailAddress;
    const superadminEmail = process.env.SUPERADMIN_EMAIL ?? "";
    if (!email || email.toLowerCase() !== superadminEmail.toLowerCase()) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    req.userId = userId;
    next();
  } catch {
    res.status(403).json({ error: "Forbidden" });
  }
}

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// ─── OG Image (any logged-in user, used in PostBuild form) ────────────────────

router.get("/og-image", requireAuth, async (req: any, res): Promise<void> => {
  const url = req.query.url as string;
  if (!url) {
    res.status(400).json({ error: "url query param required" });
    return;
  }

  let hostname: string;
  try {
    hostname = new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    res.status(400).json({ error: "Invalid URL" });
    return;
  }

  const domains = await db.select().from(approvedDomainsTable);
  const isApproved = domains.some((d) => {
    const clean = d.domain.replace(/^www\./, "").toLowerCase();
    return clean === hostname || hostname.endsWith("." + clean);
  });

  if (!isApproved) {
    res.json({ found: false, approved: false, imageUrl: null });
    return;
  }

  try {
    const pageRes = await fetch(url, {
      headers: { "User-Agent": "AirsoftArmory/1.0 (build indexer)" },
      signal: AbortSignal.timeout(6000),
    });
    const html = await pageRes.text();

    const match =
      html.match(
        /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
      ) ||
      html.match(
        /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i,
      );

    if (!match) {
      res.json({ found: false, approved: true, imageUrl: null });
      return;
    }

    let imageUrl = match[1];
    if (imageUrl.startsWith("/")) {
      const base = new URL(url);
      imageUrl = `${base.protocol}//${base.host}${imageUrl}`;
    }

    res.json({ found: true, approved: true, imageUrl });
  } catch {
    res.json({ found: false, approved: true, imageUrl: null });
  }
});

// ─── Admin: identity check ────────────────────────────────────────────────────

router.get("/admin/me", requireSuperAdmin, async (_req, res): Promise<void> => {
  res.json({ superadmin: true });
});

// ─── Admin: stats ─────────────────────────────────────────────────────────────

router.get("/admin/stats", requireSuperAdmin, async (_req, res): Promise<void> => {
  const [{ totalBuilds }] = await db
    .select({ totalBuilds: count(buildsTable.id) })
    .from(buildsTable);
  const [{ totalUpgrades }] = await db
    .select({ totalUpgrades: count(upgradesTable.id) })
    .from(upgradesTable);
  const [{ totalDomains }] = await db
    .select({ totalDomains: count(approvedDomainsTable.id) })
    .from(approvedDomainsTable);
  const distinctUsers = await db
    .selectDistinct({ userId: buildsTable.userId })
    .from(buildsTable);

  res.json({
    totalBuilds,
    totalUpgrades,
    totalDomains,
    totalUsersWithBuilds: distinctUsers.length,
  });
});

// ─── Admin: users ─────────────────────────────────────────────────────────────

router.get("/admin/users", requireSuperAdmin, async (_req, res): Promise<void> => {
  const buildCounts = await db
    .select({ userId: buildsTable.userId, buildCount: count(buildsTable.id) })
    .from(buildsTable)
    .groupBy(buildsTable.userId);

  const userIds = buildCounts.map((b) => b.userId);
  let clerkUsers: any[] = [];
  if (userIds.length > 0) {
    const resp = await clerkClient.users.getUserList({ userId: userIds, limit: 500 });
    clerkUsers = resp.data;
  }

  const superadminEmail = (process.env.SUPERADMIN_EMAIL ?? "").toLowerCase();
  const result = clerkUsers
    .map((u) => {
      const email =
        u.emailAddresses.find((e: any) => e.id === u.primaryEmailAddressId)
          ?.emailAddress ?? null;
      const bc = buildCounts.find((b) => b.userId === u.id);
      return {
        id: u.id,
        email,
        name:
          [u.firstName, u.lastName].filter(Boolean).join(" ") ||
          email ||
          u.id,
        buildCount: Number(bc?.buildCount ?? 0),
        joinedAt: new Date(u.createdAt).toISOString(),
        isSuperAdmin: email?.toLowerCase() === superadminEmail,
      };
    })
    .sort((a, b) => b.buildCount - a.buildCount);

  res.json(result);
});

// ─── Admin: user builds ───────────────────────────────────────────────────────

router.get(
  "/admin/users/:userId/builds",
  requireSuperAdmin,
  async (req, res): Promise<void> => {
    const builds = await db
      .select()
      .from(buildsTable)
      .where(eq(buildsTable.userId, req.params.userId))
      .orderBy(desc(buildsTable.createdAt));

    res.json({
      builds: builds.map((b) => ({
        id: b.id,
        gunName: b.gunName,
        category: b.category,
        totalCost: parseFloat(b.totalCost),
        specialty: b.specialty ?? null,
        createdAt: b.createdAt.toISOString(),
      })),
      total: builds.length,
    });
  },
);

// ─── Admin: approved domains ──────────────────────────────────────────────────

router.get("/admin/domains", requireSuperAdmin, async (_req, res): Promise<void> => {
  const domains = await db
    .select()
    .from(approvedDomainsTable)
    .orderBy(approvedDomainsTable.domain);
  res.json(domains);
});

router.post(
  "/admin/domains",
  requireSuperAdmin,
  async (req: any, res): Promise<void> => {
    const { domain } = req.body ?? {};
    if (!domain || typeof domain !== "string") {
      res.status(400).json({ error: "domain required" });
      return;
    }
    const clean = domain
      .toLowerCase()
      .trim()
      .replace(/^(https?:\/\/)?(www\.)?/, "")
      .replace(/\/.*$/, "")
      .trim();

    if (!clean || !/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z]{2,})+$/.test(clean)) {
      res.status(400).json({ error: "Invalid domain format. Use e.g. evike.com" });
      return;
    }

    const [{ cnt }] = await db
      .select({ cnt: count() })
      .from(approvedDomainsTable);
    if (Number(cnt) >= 50) {
      res.status(400).json({ error: "Maximum 50 domains reached" });
      return;
    }

    try {
      const [d] = await db
        .insert(approvedDomainsTable)
        .values({ domain: clean, addedBy: req.userId })
        .returning();
      res.status(201).json(d);
    } catch {
      res.status(409).json({ error: "Domain already exists" });
    }
  },
);

router.delete(
  "/admin/domains/:id",
  requireSuperAdmin,
  async (req, res): Promise<void> => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }
    await db
      .delete(approvedDomainsTable)
      .where(eq(approvedDomainsTable.id, id));
    res.sendStatus(204);
  },
);

export default router;
