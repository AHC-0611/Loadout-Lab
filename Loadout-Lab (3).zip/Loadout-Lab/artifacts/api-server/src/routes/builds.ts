import { Router, type IRouter } from "express";
import { eq, ilike, and, gte, lte, sql, desc, count, inArray, or, ne } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import {
  db,
  buildsTable,
  upgradesTable,
  userProfilesTable,
  buildRatingsTable,
  buildFavoritesTable,
  followsTable,
  friendRequestsTable,
  userAlertsTable,
  notificationsTable,
} from "@workspace/db";
import {
  ListBuildsQueryParams,
  CreateBuildBody,
  GetBuildParams,
  DeleteBuildParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

// ─── Types ────────────────────────────────────────────────────────────────────

type BuildRow = {
  id: number;
  userId: string;
  authorName: string;
  gunName: string;
  category: string;
  description: string;
  totalCost: string;
  baseCost: string | null;
  specialty: string | null;
  cons: string | null;
  gunImagePath: string | null;
  createdAt: Date;
  updatedAt: Date;
  authorSlug: string | null;
  averageRating: string | null;
  ratingCount: string;
  favoriteCount: string;
  myRating: number | null;
  isFavorited: number; // 0 or 1
};

// ─── Middleware ───────────────────────────────────────────────────────────────

function requireAuth(req: any, res: any, next: any) {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// ─── Build select fields ──────────────────────────────────────────────────────

function buildSelectFields(userId?: string) {
  return {
    id: buildsTable.id,
    userId: buildsTable.userId,
    authorName: buildsTable.authorName,
    gunName: buildsTable.gunName,
    category: buildsTable.category,
    description: buildsTable.description,
    totalCost: buildsTable.totalCost,
    baseCost: buildsTable.baseCost,
    specialty: buildsTable.specialty,
    cons: buildsTable.cons,
    gunImagePath: buildsTable.gunImagePath,
    createdAt: buildsTable.createdAt,
    updatedAt: buildsTable.updatedAt,
    authorSlug: userProfilesTable.slug,
    averageRating: sql<string | null>`(SELECT ROUND(AVG(br.rating)::numeric, 2) FROM build_ratings br WHERE br.build_id = ${buildsTable.id})`,
    ratingCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_ratings br WHERE br.build_id = ${buildsTable.id}), 0)`,
    favoriteCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_favorites bf WHERE bf.build_id = ${buildsTable.id}), 0)`,
    myRating: userId
      ? sql<number | null>`(SELECT br.rating FROM build_ratings br WHERE br.build_id = ${buildsTable.id} AND br.user_id = ${userId} LIMIT 1)`
      : sql<null>`NULL::integer`,
    isFavorited: userId
      ? sql<number>`COALESCE((SELECT 1 FROM build_favorites bf WHERE bf.build_id = ${buildsTable.id} AND bf.user_id = ${userId} LIMIT 1), 0)`
      : sql<number>`0`,
  };
}

// ─── Serializers ──────────────────────────────────────────────────────────────

function serializeBuild(b: BuildRow) {
  return {
    id: b.id,
    userId: b.userId,
    authorName: b.authorName,
    authorSlug: b.authorSlug ?? null,
    gunName: b.gunName,
    category: b.category,
    description: b.description,
    totalCost: parseFloat(b.totalCost),
    baseCost: b.baseCost != null ? parseFloat(b.baseCost) : null,
    specialty: b.specialty ?? null,
    cons: b.cons ?? null,
    gunImagePath: b.gunImagePath ?? null,
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt?.toISOString() ?? null,
    averageRating: b.averageRating != null ? parseFloat(b.averageRating) : null,
    ratingCount: parseInt(String(b.ratingCount), 10) || 0,
    favoriteCount: parseInt(String(b.favoriteCount), 10) || 0,
    myRating: b.myRating != null ? Number(b.myRating) : null,
    isFavorited: Boolean(b.isFavorited),
  };
}

function serializeUpgrade(u: typeof upgradesTable.$inferSelect) {
  return {
    id: u.id,
    buildId: u.buildId,
    name: u.name,
    price: parseFloat(u.price),
    source: u.source,
    imageUrl: u.imageUrl ?? null,
  };
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// GET /builds/stats — must be before /builds/:id
router.get("/builds/stats", async (req, res): Promise<void> => {
  const [totals] = await db
    .select({ totalBuilds: count(buildsTable.id) })
    .from(buildsTable);

  const [upgradeCount] = await db
    .select({ totalUpgrades: count(upgradesTable.id) })
    .from(upgradesTable);

  const categoryRows = await db
    .select({
      category: buildsTable.category,
      cnt: count(buildsTable.id),
    })
    .from(buildsTable)
    .groupBy(buildsTable.category)
    .orderBy(desc(count(buildsTable.id)))
    .limit(5);

  const totalBuilds = totals?.totalBuilds ?? 0;
  const totalUpgrades = upgradeCount?.totalUpgrades ?? 0;

  res.json({
    totalBuilds,
    totalUpgrades,
    avgUpgradesPerBuild:
      totalBuilds > 0 ? Math.round((totalUpgrades / totalBuilds) * 10) / 10 : 0,
    topCategories: categoryRows.map((r) => ({
      category: r.category,
      count: r.cnt,
    })),
  });
});

// GET /builds/categories — must be before /builds/:id
router.get("/builds/categories", async (_req, res): Promise<void> => {
  const rows = await db
    .selectDistinct({ category: buildsTable.category })
    .from(buildsTable)
    .orderBy(buildsTable.category);
  res.json(rows.map((r) => r.category));
});

// GET /builds/my — must be before /builds/:id
router.get("/builds/my", requireAuth, async (req: any, res): Promise<void> => {
  const builds = (await db
    .select(buildSelectFields(req.userId))
    .from(buildsTable)
    .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
    .where(eq(buildsTable.userId, req.userId))
    .orderBy(desc(buildsTable.createdAt))) as BuildRow[];

  res.json({
    builds: builds.map(serializeBuild),
    total: builds.length,
  });
});

// GET /builds
router.get("/builds", async (req, res): Promise<void> => {
  const parsed = ListBuildsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, category, minPrice, maxPrice, page = 1, limit = 20, feed } = parsed.data;

  const auth = getAuth(req);
  const userId: string | undefined =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined) ||
    undefined;

  const conditions = [];
  if (search) {
    conditions.push(
      sql`(${buildsTable.gunName} ilike ${"%" + search + "%"} OR ${buildsTable.description} ilike ${"%" + search + "%"} OR ${buildsTable.authorName} ilike ${"%" + search + "%"})`,
    );
  }
  if (category) conditions.push(eq(buildsTable.category, category));
  if (minPrice != null)
    conditions.push(gte(sql`${buildsTable.totalCost}::numeric`, minPrice));
  if (maxPrice != null)
    conditions.push(lte(sql`${buildsTable.totalCost}::numeric`, maxPrice));

  // feed=following requires authentication
  if (feed === "following" && !userId) {
    res.status(401).json({ error: "Unauthorized: sign in to view your following feed" });
    return;
  }

  // feed=following: restrict to builds by people the user follows or is friends with
  if (feed === "following" && userId) {
    const [followedRows, friendRows] = await Promise.all([
      db
        .select({ id: followsTable.followingId })
        .from(followsTable)
        .where(eq(followsTable.followerId, userId)),
      db
        .select({
          id: sql<string>`CASE WHEN sender_id = ${userId} THEN receiver_id ELSE sender_id END`,
        })
        .from(friendRequestsTable)
        .where(
          and(
            eq(friendRequestsTable.status, "accepted"),
            or(
              eq(friendRequestsTable.senderId, userId),
              eq(friendRequestsTable.receiverId, userId),
            ),
          ),
        ),
    ]);

    const allIds = [
      ...new Set([
        ...followedRows.map((r) => r.id),
        ...friendRows.map((r) => r.id),
      ]),
    ];

    if (allIds.length === 0) {
      res.json({ builds: [], total: 0 });
      return;
    }

    conditions.push(inArray(buildsTable.userId, allIds));
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [builds, [{ total }]] = await Promise.all([
    db
      .select(buildSelectFields(userId))
      .from(buildsTable)
      .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
      .where(where)
      .orderBy(desc(buildsTable.createdAt))
      .limit(limit ?? 20)
      .offset(((page ?? 1) - 1) * (limit ?? 20)),
    db
      .select({ total: count(buildsTable.id) })
      .from(buildsTable)
      .where(where),
  ]);

  res.json({
    builds: (builds as BuildRow[]).map(serializeBuild),
    total,
  });
});

// POST /builds
router.post("/builds", requireAuth, async (req: any, res): Promise<void> => {
  const parsed = CreateBuildBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { gunName, category, description, upgrades, baseCost, specialty, cons, gunImagePath } =
    parsed.data;
  const totalCost = upgrades.reduce((sum, u) => sum + (u.price ?? 0), 0);

  const [profile] = await db
    .select({
      username: userProfilesTable.username,
      displayName: userProfilesTable.displayName,
      slug: userProfilesTable.slug,
    })
    .from(userProfilesTable)
    .where(eq(userProfilesTable.userId, req.userId))
    .limit(1);

  const auth = getAuth(req);
  const authorName = profile
    ? profile.displayName || profile.username
    : ((auth?.sessionClaims?.["name"] as string) ||
       (auth?.sessionClaims?.["email"] as string) ||
       "Anonymous");

  const [build] = await db
    .insert(buildsTable)
    .values({
      userId: req.userId,
      authorName,
      gunName,
      category,
      description: description ?? "",
      totalCost: String(totalCost),
      baseCost: baseCost != null ? String(baseCost) : null,
      specialty: specialty ?? null,
      cons: cons ?? null,
      gunImagePath: gunImagePath ?? null,
    })
    .returning();

  if (upgrades.length > 0) {
    await db.insert(upgradesTable).values(
      upgrades.map((u) => ({
        buildId: build.id,
        name: u.name,
        price: String(u.price),
        source: u.source,
        imageUrl: u.imageUrl ?? null,
      })),
    );
  }

  const serialized: BuildRow = {
    ...build,
    authorSlug: profile?.slug ?? null,
    averageRating: null,
    ratingCount: "0",
    favoriteCount: "0",
    myRating: null,
    isFavorited: 0,
  };
  res.status(201).json(serializeBuild(serialized));
});

// GET /builds/:id
router.get("/builds/:id", async (req, res): Promise<void> => {
  const params = GetBuildParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const auth = getAuth(req);
  const userId: string | undefined =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined) ||
    undefined;

  const [build] = (await db
    .select(buildSelectFields(userId))
    .from(buildsTable)
    .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
    .where(eq(buildsTable.id, params.data.id))) as BuildRow[];

  if (!build) {
    res.status(404).json({ error: "Build not found" });
    return;
  }

  const upgrades = await db
    .select()
    .from(upgradesTable)
    .where(eq(upgradesTable.buildId, build.id))
    .orderBy(upgradesTable.id);

  res.json({
    ...serializeBuild(build),
    upgrades: upgrades.map(serializeUpgrade),
  });
});

// DELETE /builds/:id
router.delete(
  "/builds/:id",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const params = DeleteBuildParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    const [build] = await db
      .select()
      .from(buildsTable)
      .where(eq(buildsTable.id, params.data.id));

    if (!build) {
      res.status(404).json({ error: "Build not found" });
      return;
    }

    if (build.userId !== req.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    await db.delete(buildsTable).where(eq(buildsTable.id, params.data.id));
    res.sendStatus(204);
  },
);

export default router;
