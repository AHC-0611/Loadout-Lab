/**
 * Build alerts routes
 *
 * GET    /api/alerts         — list own alerts
 * POST   /api/alerts         — create an alert
 * DELETE /api/alerts/:id     — delete own alert
 *
 * Autocomplete helpers (used by the Armory page form):
 * GET    /api/alerts/suggestions/gun-names   — distinct gun names from builds
 * GET    /api/alerts/suggestions/part-names  — distinct part names from upgrades
 */

import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { eq, and, desc, sql } from "drizzle-orm";
import { db, userAlertsTable, buildsTable, upgradesTable } from "@workspace/db";

const router: IRouter = Router();

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId as string;
  next();
}

// GET /alerts/suggestions/gun-names
router.get("/alerts/suggestions/gun-names", requireAuth, async (_req, res): Promise<void> => {
  const rows = await db
    .selectDistinct({ gunName: buildsTable.gunName })
    .from(buildsTable)
    .orderBy(buildsTable.gunName)
    .limit(100);
  res.json({ suggestions: rows.map((r) => r.gunName) });
});

// GET /alerts/suggestions/part-names
router.get("/alerts/suggestions/part-names", requireAuth, async (_req, res): Promise<void> => {
  const rows = await db
    .selectDistinct({ name: upgradesTable.name })
    .from(upgradesTable)
    .orderBy(upgradesTable.name)
    .limit(100);
  res.json({ suggestions: rows.map((r) => r.name) });
});

// GET /alerts
router.get("/alerts", requireAuth, async (req: any, res): Promise<void> => {
  const alerts = await db
    .select()
    .from(userAlertsTable)
    .where(eq(userAlertsTable.userId, req.userId))
    .orderBy(desc(userAlertsTable.createdAt));

  res.json({ alerts });
});

// POST /alerts
router.post("/alerts", requireAuth, async (req: any, res): Promise<void> => {
  const { type, value } = req.body ?? {};

  if (type !== "gun_model" && type !== "part") {
    res.status(400).json({ error: "type must be 'gun_model' or 'part'" });
    return;
  }
  if (!value || typeof value !== "string" || !value.trim()) {
    res.status(400).json({ error: "value is required" });
    return;
  }

  // Cap at 20 alerts per user
  const [{ count }] = await db
    .select({ count: sql<string>`COUNT(*)` })
    .from(userAlertsTable)
    .where(eq(userAlertsTable.userId, req.userId));

  if (parseInt(count, 10) >= 20) {
    res.status(409).json({ error: "Alert limit reached (20 maximum)" });
    return;
  }

  const [alert] = await db
    .insert(userAlertsTable)
    .values({ userId: req.userId, type, value: value.trim() })
    .onConflictDoNothing()
    .returning();

  if (!alert) {
    res.status(409).json({ error: "Identical alert already exists" });
    return;
  }

  res.status(201).json({ alert });
});

// DELETE /alerts/:id
router.delete("/alerts/:id", requireAuth, async (req: any, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [alert] = await db
    .select()
    .from(userAlertsTable)
    .where(eq(userAlertsTable.id, id))
    .limit(1);

  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }

  if (alert.userId !== req.userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(userAlertsTable).where(eq(userAlertsTable.id, id));
  res.json({ deleted: true });
});

export default router;
