/**
 * Stripe payments routes
 *
 * POST /api/payments/verified-checkout  — create a Stripe Checkout session for $5 verified badge
 * POST /api/payments/webhook            — Stripe webhook handler (signature verified)
 *
 * Secrets required in environment:
 *   STRIPE_SECRET_KEY      — Stripe secret key (sk_live_... or sk_test_...)
 *   STRIPE_WEBHOOK_SECRET  — Stripe webhook signing secret (whsec_...)
 */

import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import { db, userProfilesTable } from "@workspace/db";
import Stripe from "stripe";

const router: IRouter = Router();

function getStripe(): Stripe | null {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  return new Stripe(key, { apiVersion: "2025-06-30.basil" });
}

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId as string;
  next();
}

// ─── POST /payments/verified-checkout ────────────────────────────────────────

router.post(
  "/payments/verified-checkout",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const stripe = getStripe();
    if (!stripe) {
      res.status(503).json({ error: "Stripe is not configured" });
      return;
    }

    // Look up their profile to get slug and verify they're not already verified
    const [profile] = await db
      .select({ isVerified: userProfilesTable.isVerified, slug: userProfilesTable.slug })
      .from(userProfilesTable)
      .where(eq(userProfilesTable.userId, req.userId))
      .limit(1);

    if (!profile) {
      res.status(404).json({ error: "Profile not found" });
      return;
    }

    if (profile.isVerified) {
      res.status(409).json({ error: "Already verified" });
      return;
    }

    // Derive app origin from the request
    const origin =
      process.env.APP_ORIGIN ||
      `${req.protocol}://${req.get("host")}`;
    const basePath = "/airsoft-armory";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: "usd",
            unit_amount: 500, // $5.00 in cents
            product_data: {
              name: "Verified Builder Badge",
              description:
                "Lifetime gold badge on your profile and builds, custom profile background color, and ad-free browsing.",
            },
          },
          quantity: 1,
        },
      ],
      metadata: {
        userId: req.userId,
      },
      success_url: `${origin}${basePath}/settings/profile?verified=1`,
      cancel_url: `${origin}${basePath}/settings/profile?verified=0`,
    });

    res.json({ url: session.url });
  },
);

// ─── POST /payments/webhook ───────────────────────────────────────────────────
// Must receive raw body — Express.json() must NOT parse this route.
// Raw body middleware is applied in index.ts selectively.

router.post(
  "/payments/webhook",
  async (req: any, res): Promise<void> => {
    const stripe = getStripe();
    if (!stripe) {
      res.status(503).json({ error: "Stripe is not configured" });
      return;
    }

    const sig = req.headers["stripe-signature"] as string;
    const secret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!secret) {
      res.status(503).json({ error: "Webhook secret not configured" });
      return;
    }

    let event: Stripe.Event;
    try {
      // req.rawBody is populated by a custom middleware in index.ts for this path
      event = stripe.webhooks.constructEvent(req.rawBody ?? req.body, sig, secret);
    } catch (err: any) {
      res.status(400).json({ error: `Webhook signature verification failed: ${err.message}` });
      return;
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.userId;

      if (userId) {
        // Idempotent: set isVerified = true and initialize default profileBgColor
        const [existing] = await db
          .select({ isVerified: userProfilesTable.isVerified, profileBgColor: userProfilesTable.profileBgColor })
          .from(userProfilesTable)
          .where(eq(userProfilesTable.userId, userId))
          .limit(1);

        if (existing && !existing.isVerified) {
          await db
            .update(userProfilesTable)
            .set({
              isVerified: true,
              // Gold-tinted default background for new verified users
              profileBgColor: existing.profileBgColor ?? "#d4a017",
            })
            .where(eq(userProfilesTable.userId, userId));
        }
      }
    }

    res.json({ received: true });
  },
);

export default router;
