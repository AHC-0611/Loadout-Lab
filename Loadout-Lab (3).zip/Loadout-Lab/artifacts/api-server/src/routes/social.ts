/**
 * Social routes: follows + friend requests
 *
 * ── Canonical pair ordering ──────────────────────────────────────────────────
 * Friend-request rows always store:
 *   senderId   = LEAST(userA, userB)    — lexicographically smaller userId
 *   receiverId = GREATEST(userA, userB) — lexicographically larger userId
 *   initiatorId = the userId who actually triggered the request
 *
 * This means the unique(sender_id, receiver_id) constraint covers BOTH
 * directions, and there can never be two rows for the same pair.
 * The advisory-lock + transaction makes create/auto-accept atomic.
 *
 * Follow (asymmetric):
 *   POST   /users/:slug/follow          — follow a user
 *   DELETE /users/:slug/follow          — unfollow
 *   GET    /users/:slug/followers       — list followers
 *   GET    /users/:slug/following       — list following
 *
 * Friend requests (mutual):
 *   POST   /users/:slug/friend-request  — send a friend request
 *   PATCH  /friend-requests/:id         — accept or decline (non-initiator only)
 *   DELETE /friend-requests/:id         — cancel sent request or remove friend
 *   GET    /friend-requests/incoming    — pending received requests
 *   GET    /friend-requests/outgoing    — pending sent requests
 *   GET    /friends                     — accepted friends list
 *
 * Summary:
 *   GET    /me/social-summary           — pending request count + unread badge
 */

import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { eq, and, or, desc, sql, ne } from "drizzle-orm";
import {
  db,
  userProfilesTable,
  followsTable,
  friendRequestsTable,
} from "@workspace/db";

const router: IRouter = Router();

// ─── Middleware ───────────────────────────────────────────────────────────────

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId as string;
  next();
}

// ─── Canonical pair helpers ───────────────────────────────────────────────────

/**
 * Returns { canonSender, canonReceiver } where canonSender < canonReceiver.
 * This guarantees the same row is found/updated regardless of who initiates.
 */
function canonicalPair(a: string, b: string): { canonSender: string; canonReceiver: string } {
  return a < b
    ? { canonSender: a, canonReceiver: b }
    : { canonSender: b, canonReceiver: a };
}

/**
 * A stable 64-bit advisory lock key derived from the canonical pair.
 * Uses a simple polynomial hash → fits in a signed bigint (JS number).
 */
function pairLockKey(a: string, b: string): number {
  const { canonSender, canonReceiver } = canonicalPair(a, b);
  const key = `fr:${canonSender}:${canonReceiver}`;
  let h = 0;
  for (let i = 0; i < key.length; i++) {
    h = Math.imul(31, h) + key.charCodeAt(i);
    h |= 0; // keep 32-bit
  }
  // Shift into positive range and stay within safe integer (use low 48 bits)
  return (h >>> 0) * 65536 + 42;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function resolveSlug(
  slug: string,
  res: any,
): Promise<(typeof userProfilesTable.$inferSelect) | null> {
  const [profile] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.slug, slug))
    .limit(1);
  if (!profile) {
    res.status(404).json({ error: "User not found" });
    return null;
  }
  return profile;
}

function serializeUser(p: typeof userProfilesTable.$inferSelect) {
  return {
    userId: p.userId,
    username: p.username,
    slug: p.slug,
    displayName: p.displayName ?? null,
    avatarPath: p.avatarPath ?? null,
    isVerified: p.isVerified,
  };
}

// ─── Follow routes ────────────────────────────────────────────────────────────

// POST /users/:slug/follow
router.post(
  "/users/:slug/follow",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const target = await resolveSlug(req.params.slug, res);
    if (!target) return;

    if (target.userId === req.userId) {
      res.status(400).json({ error: "Cannot follow yourself" });
      return;
    }

    await db
      .insert(followsTable)
      .values({ followerId: req.userId, followingId: target.userId })
      .onConflictDoNothing();

    const [{ count }] = await db
      .select({ count: sql<string>`COUNT(*)` })
      .from(followsTable)
      .where(eq(followsTable.followingId, target.userId));

    res.json({ following: true, followerCount: parseInt(count, 10) || 0 });
  },
);

// DELETE /users/:slug/follow
router.delete(
  "/users/:slug/follow",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const target = await resolveSlug(req.params.slug, res);
    if (!target) return;

    await db
      .delete(followsTable)
      .where(
        and(
          eq(followsTable.followerId, req.userId),
          eq(followsTable.followingId, target.userId),
        ),
      );

    const [{ count }] = await db
      .select({ count: sql<string>`COUNT(*)` })
      .from(followsTable)
      .where(eq(followsTable.followingId, target.userId));

    res.json({ following: false, followerCount: parseInt(count, 10) || 0 });
  },
);

// GET /users/:slug/followers
router.get(
  "/users/:slug/followers",
  async (req, res): Promise<void> => {
    const target = await resolveSlug(req.params.slug, res);
    if (!target) return;

    const rows = await db
      .select({ profile: userProfilesTable })
      .from(followsTable)
      .innerJoin(
        userProfilesTable,
        eq(followsTable.followerId, userProfilesTable.userId),
      )
      .where(eq(followsTable.followingId, target.userId))
      .orderBy(desc(followsTable.createdAt));

    res.json({ users: rows.map((r) => serializeUser(r.profile)) });
  },
);

// GET /users/:slug/following
router.get(
  "/users/:slug/following",
  async (req, res): Promise<void> => {
    const target = await resolveSlug(req.params.slug, res);
    if (!target) return;

    const rows = await db
      .select({ profile: userProfilesTable })
      .from(followsTable)
      .innerJoin(
        userProfilesTable,
        eq(followsTable.followingId, userProfilesTable.userId),
      )
      .where(eq(followsTable.followerId, target.userId))
      .orderBy(desc(followsTable.createdAt));

    res.json({ users: rows.map((r) => serializeUser(r.profile)) });
  },
);

// ─── Friend request routes ────────────────────────────────────────────────────

// POST /users/:slug/friend-request
// Atomic: uses pg_advisory_xact_lock on the canonical pair so concurrent
// cross-direction requests cannot both succeed.
router.post(
  "/users/:slug/friend-request",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const target = await resolveSlug(req.params.slug, res);
    if (!target) return;

    if (target.userId === req.userId) {
      res.status(400).json({ error: "Cannot friend yourself" });
      return;
    }

    const { canonSender, canonReceiver } = canonicalPair(req.userId, target.userId);
    const lockKey = pairLockKey(req.userId, target.userId);

    let responseStatus = 201;
    let responseBody: { status: string; requestId: number };

    await db.transaction(async (tx) => {
      // Acquire advisory lock scoped to this transaction
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${lockKey})`);

      const [existing] = await tx
        .select()
        .from(friendRequestsTable)
        .where(
          and(
            eq(friendRequestsTable.senderId, canonSender),
            eq(friendRequestsTable.receiverId, canonReceiver),
          ),
        )
        .limit(1);

      if (existing) {
        if (existing.status === "accepted") {
          throw Object.assign(new Error("Already friends"), { statusCode: 409 });
        }

        if (existing.status === "pending") {
          if (existing.initiatorId === req.userId) {
            // We already sent — idempotent
            throw Object.assign(new Error("Request already sent"), { statusCode: 409 });
          }
          // The other party sent a request to us — auto-accept
          const [updated] = await tx
            .update(friendRequestsTable)
            .set({ status: "accepted" })
            .where(eq(friendRequestsTable.id, existing.id))
            .returning();
          responseStatus = 200;
          responseBody = { status: "accepted", requestId: updated.id };
          return;
        }

        // Declined — allow re-initiate by resetting
        const [updated] = await tx
          .update(friendRequestsTable)
          .set({ status: "pending", initiatorId: req.userId })
          .where(eq(friendRequestsTable.id, existing.id))
          .returning();
        responseStatus = 200;
        responseBody = { status: "pending", requestId: updated.id };
        return;
      }

      // No existing row — create
      const [created] = await tx
        .insert(friendRequestsTable)
        .values({ senderId: canonSender, receiverId: canonReceiver, initiatorId: req.userId })
        .returning();

      responseBody = { status: "pending", requestId: created.id };
    }).catch((err: any) => {
      if (err.statusCode) {
        res.status(err.statusCode).json({ error: err.message });
        throw err; // signal outer catch to skip double-response
      }
      throw err;
    });

    // If res was already sent by the catch handler, bail
    if (res.headersSent) return;
    res.status(responseStatus).json(responseBody!);
  },
);

// PATCH /friend-requests/:id  — accept or decline (non-initiator only)
router.patch(
  "/friend-requests/:id",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }

    const { action } = req.body ?? {};
    if (action !== "accept" && action !== "decline") {
      res.status(400).json({ error: "action must be 'accept' or 'decline'" });
      return;
    }

    const [request] = await db
      .select()
      .from(friendRequestsTable)
      .where(eq(friendRequestsTable.id, id))
      .limit(1);

    if (!request) {
      res.status(404).json({ error: "Request not found" });
      return;
    }

    // Only the non-initiator (recipient) may accept/decline
    const isParty =
      request.senderId === req.userId || request.receiverId === req.userId;
    if (!isParty) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (request.initiatorId === req.userId) {
      res.status(403).json({ error: "Cannot respond to your own request" });
      return;
    }

    if (request.status !== "pending") {
      res.status(409).json({ error: "Request already resolved" });
      return;
    }

    const newStatus = action === "accept" ? "accepted" : "declined";
    await db
      .update(friendRequestsTable)
      .set({ status: newStatus })
      .where(eq(friendRequestsTable.id, id));

    res.json({ status: newStatus, requestId: id });
  },
);

// DELETE /friend-requests/:id  — cancel sent request OR remove friend
router.delete(
  "/friend-requests/:id",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }

    const [request] = await db
      .select()
      .from(friendRequestsTable)
      .where(eq(friendRequestsTable.id, id))
      .limit(1);

    if (!request) {
      res.status(404).json({ error: "Request not found" });
      return;
    }

    const isParty =
      request.senderId === req.userId || request.receiverId === req.userId;
    if (!isParty) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    await db
      .delete(friendRequestsTable)
      .where(eq(friendRequestsTable.id, id));

    res.json({ removed: true });
  },
);

// GET /friend-requests/incoming
// Returns pending requests where req.userId is NOT the initiator (someone sent to us).
router.get(
  "/friend-requests/incoming",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const rows = await db
      .select({
        id: friendRequestsTable.id,
        status: friendRequestsTable.status,
        createdAt: friendRequestsTable.createdAt,
        initiatorId: friendRequestsTable.initiatorId,
        senderId: friendRequestsTable.senderId,
        receiverId: friendRequestsTable.receiverId,
        initiatorProfile: userProfilesTable,
      })
      .from(friendRequestsTable)
      .innerJoin(
        userProfilesTable,
        eq(friendRequestsTable.initiatorId, userProfilesTable.userId),
      )
      .where(
        and(
          // User is a party to the request
          or(
            eq(friendRequestsTable.senderId, req.userId),
            eq(friendRequestsTable.receiverId, req.userId),
          ),
          // But NOT the initiator (someone sent it to us)
          ne(friendRequestsTable.initiatorId, req.userId),
          eq(friendRequestsTable.status, "pending"),
        ),
      )
      .orderBy(desc(friendRequestsTable.createdAt));

    res.json({
      requests: rows.map((r) => ({
        id: r.id,
        status: r.status,
        createdAt: r.createdAt.toISOString(),
        sender: serializeUser(r.initiatorProfile),
      })),
    });
  },
);

// GET /friend-requests/outgoing
// Returns pending requests where req.userId IS the initiator.
router.get(
  "/friend-requests/outgoing",
  requireAuth,
  async (req: any, res): Promise<void> => {
    // Join on the OTHER party (not the initiator)
    const rows = await db
      .select({
        id: friendRequestsTable.id,
        status: friendRequestsTable.status,
        createdAt: friendRequestsTable.createdAt,
        senderId: friendRequestsTable.senderId,
        receiverId: friendRequestsTable.receiverId,
        otherProfile: userProfilesTable,
      })
      .from(friendRequestsTable)
      .innerJoin(
        userProfilesTable,
        // Join on the party that is NOT the current user
        sql`${userProfilesTable.userId} = CASE
          WHEN ${friendRequestsTable.senderId} = ${req.userId}
          THEN ${friendRequestsTable.receiverId}
          ELSE ${friendRequestsTable.senderId}
        END`,
      )
      .where(
        and(
          eq(friendRequestsTable.initiatorId, req.userId),
          eq(friendRequestsTable.status, "pending"),
        ),
      )
      .orderBy(desc(friendRequestsTable.createdAt));

    res.json({
      requests: rows.map((r) => ({
        id: r.id,
        status: r.status,
        createdAt: r.createdAt.toISOString(),
        receiver: serializeUser(r.otherProfile),
      })),
    });
  },
);

// GET /friends — accepted friendships; join on the OTHER party's profile
router.get(
  "/friends",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const rows = await db
      .select({
        id: friendRequestsTable.id,
        updatedAt: friendRequestsTable.updatedAt,
        otherProfile: userProfilesTable,
      })
      .from(friendRequestsTable)
      .innerJoin(
        userProfilesTable,
        sql`${userProfilesTable.userId} = CASE
          WHEN ${friendRequestsTable.senderId} = ${req.userId}
          THEN ${friendRequestsTable.receiverId}
          ELSE ${friendRequestsTable.senderId}
        END`,
      )
      .where(
        and(
          eq(friendRequestsTable.status, "accepted"),
          or(
            eq(friendRequestsTable.senderId, req.userId),
            eq(friendRequestsTable.receiverId, req.userId),
          ),
        ),
      )
      .orderBy(desc(friendRequestsTable.updatedAt));

    res.json({
      friends: rows.map((r) => ({
        requestId: r.id,
        friendedAt: r.updatedAt.toISOString(),
        user: serializeUser(r.otherProfile),
      })),
    });
  },
);

// GET /me/social-summary
router.get(
  "/me/social-summary",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const [{ pendingCount }, [{ followerCount }], [{ followingCount }], [{ friendCount }]] =
      await Promise.all([
        db
          .select({ pendingCount: sql<string>`COUNT(*)` })
          .from(friendRequestsTable)
          .where(
            and(
              // User is a party
              or(
                eq(friendRequestsTable.senderId, req.userId),
                eq(friendRequestsTable.receiverId, req.userId),
              ),
              // But NOT the initiator
              ne(friendRequestsTable.initiatorId, req.userId),
              eq(friendRequestsTable.status, "pending"),
            ),
          )
          .then((r) => r[0]),
        db
          .select({ followerCount: sql<string>`COUNT(*)` })
          .from(followsTable)
          .where(eq(followsTable.followingId, req.userId)),
        db
          .select({ followingCount: sql<string>`COUNT(*)` })
          .from(followsTable)
          .where(eq(followsTable.followerId, req.userId)),
        db
          .select({ friendCount: sql<string>`COUNT(*)` })
          .from(friendRequestsTable)
          .where(
            and(
              eq(friendRequestsTable.status, "accepted"),
              or(
                eq(friendRequestsTable.senderId, req.userId),
                eq(friendRequestsTable.receiverId, req.userId),
              ),
            ),
          ),
      ]);

    res.json({
      pendingFriendRequests: parseInt(pendingCount, 10) || 0,
      followerCount: parseInt(followerCount, 10) || 0,
      followingCount: parseInt(followingCount, 10) || 0,
      friendCount: parseInt(friendCount, 10) || 0,
    });
  },
);

export default router;
