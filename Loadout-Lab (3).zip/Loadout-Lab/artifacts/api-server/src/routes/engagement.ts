/**
 * Engagement routes: ratings + favorites
 *
 * Ratings:
 *   POST   /builds/:id/ratings   — upsert own rating (1-5)
 *   DELETE /builds/:id/ratings   — remove own rating
 *   GET    /ratings/mine         — all builds this user has rated
 *
 * Favorites:
 *   POST   /builds/:id/favorite  — toggle favorite (returns { favorited: bool })
 *   GET    /favorites/mine       — all builds this user has favorited
 */

import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { eq, and, desc, sql } from "drizzle-orm";
import {
  db,
  buildsTable,
  upgradesTable,
  userProfilesTable,
  buildRatingsTable,
  buildFavoritesTable,
} from "@workspace/db";

const router: IRouter = Router();

// ─── Middleware ───────────────────────────────────────────────────────────────

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// ─── Serializer helpers ──────────────────────────────────────────────────────

type RatedBuildRow = {
  id: number;
  userId: string;
  authorName: string;
  authorSlug: string | null;
  gunName: string;
  category: string;
  description: string;
  totalCost: string;
  baseCost: string | null;
  specialty: string | null;
  cons: string | null;
  gunImagePath: string | null;
  createdAt: Date;
  updatedAt: Date;
  myRating: number;
  ratedAt: Date;
};

function serializeRatedBuild(b: RatedBuildRow) {
  return {
    id: b.id,
    userId: b.userId,
    authorName: b.authorName,
    authorSlug: b.authorSlug ?? null,
    gunName: b.gunName,
    category: b.category,
    description: b.description,
    totalCost: parseFloat(b.totalCost),
    baseCost: b.baseCost != null ? parseFloat(b.baseCost) : null,
    specialty: b.specialty ?? null,
    cons: b.cons ?? null,
    gunImagePath: b.gunImagePath ?? null,
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt?.toISOString() ?? null,
    myRating: b.myRating,
    ratedAt: b.ratedAt.toISOString(),
  };
}

type FavoritedBuildRow = Omit<RatedBuildRow, "myRating" | "ratedAt"> & {
  myRating: number | null;
  averageRating: string | null;
  ratingCount: string;
  favoriteCount: string;
  favoritedAt: Date;
};

function serializeFavoritedBuild(b: FavoritedBuildRow) {
  return {
    id: b.id,
    userId: b.userId,
    authorName: b.authorName,
    authorSlug: b.authorSlug ?? null,
    gunName: b.gunName,
    category: b.category,
    description: b.description,
    totalCost: parseFloat(b.totalCost),
    baseCost: b.baseCost != null ? parseFloat(b.baseCost) : null,
    specialty: b.specialty ?? null,
    cons: b.cons ?? null,
    gunImagePath: b.gunImagePath ?? null,
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt?.toISOString() ?? null,
    averageRating: b.averageRating != null ? parseFloat(b.averageRating) : null,
    ratingCount: parseInt(String(b.ratingCount), 10) || 0,
    favoriteCount: parseInt(String(b.favoriteCount), 10) || 0,
    myRating: b.myRating ?? null,
    isFavorited: true,
    favoritedAt: b.favoritedAt.toISOString(),
  };
}

// ─── Rating routes ────────────────────────────────────────────────────────────

// POST /builds/:id/ratings — upsert own rating
router.post(
  "/builds/:id/ratings",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const buildId = parseInt(req.params.id, 10);
    if (isNaN(buildId)) { res.status(400).json({ error: "Invalid build id" }); return; }

    const { rating } = req.body ?? {};
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      res.status(400).json({ error: "Rating must be an integer between 1 and 5" });
      return;
    }

    // Check build exists
    const [build] = await db.select({ id: buildsTable.id })
      .from(buildsTable).where(eq(buildsTable.id, buildId)).limit(1);
    if (!build) { res.status(404).json({ error: "Build not found" }); return; }

    // Upsert via ON CONFLICT
    await db
      .insert(buildRatingsTable)
      .values({ userId: req.userId, buildId, rating })
      .onConflictDoUpdate({
        target: [buildRatingsTable.userId, buildRatingsTable.buildId],
        set: { rating, updatedAt: new Date() },
      });

    // Return updated aggregate stats
    const [[avg]] = await Promise.all([
      db
        .select({
          averageRating: sql<string | null>`ROUND(AVG(${buildRatingsTable.rating})::numeric, 2)`,
          ratingCount: sql<string>`COUNT(*)`,
        })
        .from(buildRatingsTable)
        .where(eq(buildRatingsTable.buildId, buildId)),
    ]);

    res.json({
      myRating: rating,
      averageRating: avg.averageRating != null ? parseFloat(avg.averageRating) : null,
      ratingCount: parseInt(avg.ratingCount, 10) || 0,
    });
  },
);

// DELETE /builds/:id/ratings — remove own rating
router.delete(
  "/builds/:id/ratings",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const buildId = parseInt(req.params.id, 10);
    if (isNaN(buildId)) { res.status(400).json({ error: "Invalid build id" }); return; }

    await db
      .delete(buildRatingsTable)
      .where(
        and(
          eq(buildRatingsTable.userId, req.userId),
          eq(buildRatingsTable.buildId, buildId),
        ),
      );

    const [avg] = await db
      .select({
        averageRating: sql<string | null>`ROUND(AVG(${buildRatingsTable.rating})::numeric, 2)`,
        ratingCount: sql<string>`COUNT(*)`,
      })
      .from(buildRatingsTable)
      .where(eq(buildRatingsTable.buildId, buildId));

    res.json({
      myRating: null,
      averageRating: avg?.averageRating != null ? parseFloat(avg.averageRating) : null,
      ratingCount: parseInt(avg?.ratingCount ?? "0", 10) || 0,
    });
  },
);

// GET /ratings/mine — builds this user has rated
router.get(
  "/ratings/mine",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const rows = await db
      .select({
        id: buildsTable.id,
        userId: buildsTable.userId,
        authorName: buildsTable.authorName,
        authorSlug: userProfilesTable.slug,
        gunName: buildsTable.gunName,
        category: buildsTable.category,
        description: buildsTable.description,
        totalCost: buildsTable.totalCost,
        baseCost: buildsTable.baseCost,
        specialty: buildsTable.specialty,
        cons: buildsTable.cons,
        gunImagePath: buildsTable.gunImagePath,
        createdAt: buildsTable.createdAt,
        updatedAt: buildsTable.updatedAt,
        myRating: buildRatingsTable.rating,
        ratedAt: buildRatingsTable.updatedAt,
      })
      .from(buildRatingsTable)
      .innerJoin(buildsTable, eq(buildRatingsTable.buildId, buildsTable.id))
      .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
      .where(eq(buildRatingsTable.userId, req.userId))
      .orderBy(desc(buildRatingsTable.updatedAt));

    res.json({ ratings: rows.map(serializeRatedBuild) });
  },
);

// ─── Favorite routes ──────────────────────────────────────────────────────────

// POST /builds/:id/favorite — toggle
router.post(
  "/builds/:id/favorite",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const buildId = parseInt(req.params.id, 10);
    if (isNaN(buildId)) { res.status(400).json({ error: "Invalid build id" }); return; }

    const [build] = await db.select({ id: buildsTable.id })
      .from(buildsTable).where(eq(buildsTable.id, buildId)).limit(1);
    if (!build) { res.status(404).json({ error: "Build not found" }); return; }

    // Concurrency-safe toggle using a transaction-scoped PostgreSQL advisory
    // lock keyed by (userId, buildId). pg_advisory_xact_lock serializes ALL
    // requests for the same pair — including concurrent inserts when no row
    // exists yet — eliminating the unique-constraint race that SELECT FOR UPDATE
    // cannot prevent on absent rows.
    const favorited = await db.transaction(async (tx) => {
      // Acquire advisory lock: released automatically at transaction end.
      // hashtext produces a stable int4; cast to bigint to match the advisory API.
      await tx.execute(
        sql`SELECT pg_advisory_xact_lock(hashtext(${req.userId} || ':' || ${String(buildId)}))`,
      );

      const [existing] = await tx
        .select({ id: buildFavoritesTable.id })
        .from(buildFavoritesTable)
        .where(
          and(
            eq(buildFavoritesTable.userId, req.userId),
            eq(buildFavoritesTable.buildId, buildId),
          ),
        )
        .limit(1);

      if (existing) {
        await tx
          .delete(buildFavoritesTable)
          .where(eq(buildFavoritesTable.id, existing.id));
        return false;
      } else {
        await tx
          .insert(buildFavoritesTable)
          .values({ userId: req.userId, buildId });
        return true;
      }
    });

    const [fav] = await db
      .select({ favoriteCount: sql<string>`COUNT(*)` })
      .from(buildFavoritesTable)
      .where(eq(buildFavoritesTable.buildId, buildId));

    res.json({
      favorited,
      favoriteCount: parseInt(fav?.favoriteCount ?? "0", 10) || 0,
    });
  },
);

// GET /favorites/mine — builds this user has favorited
router.get(
  "/favorites/mine",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const rows = (await db
      .select({
        id: buildsTable.id,
        userId: buildsTable.userId,
        authorName: buildsTable.authorName,
        authorSlug: userProfilesTable.slug,
        gunName: buildsTable.gunName,
        category: buildsTable.category,
        description: buildsTable.description,
        totalCost: buildsTable.totalCost,
        baseCost: buildsTable.baseCost,
        specialty: buildsTable.specialty,
        cons: buildsTable.cons,
        gunImagePath: buildsTable.gunImagePath,
        createdAt: buildsTable.createdAt,
        updatedAt: buildsTable.updatedAt,
        favoritedAt: buildFavoritesTable.createdAt,
        averageRating: sql<string | null>`(SELECT ROUND(AVG(br.rating)::numeric, 2) FROM build_ratings br WHERE br.build_id = ${buildsTable.id})`,
        ratingCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_ratings br WHERE br.build_id = ${buildsTable.id}), 0)`,
        favoriteCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_favorites bf WHERE bf.build_id = ${buildsTable.id}), 0)`,
        myRating: sql<number | null>`(SELECT br.rating FROM build_ratings br WHERE br.build_id = ${buildsTable.id} AND br.user_id = ${req.userId})`,
      })
      .from(buildFavoritesTable)
      .innerJoin(buildsTable, eq(buildFavoritesTable.buildId, buildsTable.id))
      .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
      .where(eq(buildFavoritesTable.userId, req.userId))
      .orderBy(desc(buildFavoritesTable.createdAt))) as FavoritedBuildRow[];

    res.json({
      favorites: rows.map(serializeFavoritedBuild),
    });
  },
);

export default router;
