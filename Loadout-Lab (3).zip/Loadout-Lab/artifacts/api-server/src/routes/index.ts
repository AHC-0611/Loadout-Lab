import { Router, type IRouter } from "express";
import healthRouter from "./health";
import buildsRouter from "./builds";
import storageRouter from "./storage";
import adminRouter from "./admin";
import profilesRouter from "./profiles";
import engagementRouter from "./engagement";
import socialRouter from "./social";
import alertsRouter from "./alerts";
import notificationsRouter from "./notifications";
import paymentsRouter from "./payments";

const router: IRouter = Router();

router.use(healthRouter);
router.use(storageRouter);
router.use(adminRouter);
router.use(profilesRouter);
router.use(engagementRouter);
router.use(socialRouter);
router.use(alertsRouter);
router.use(notificationsRouter);
router.use(paymentsRouter);
router.use(buildsRouter);

export default router;
