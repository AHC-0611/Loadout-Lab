/**
 * Notifications routes
 *
 * GET    /api/notifications            — recent 20 notifications, newest first
 * PATCH  /api/notifications/read-all   — mark all as read
 * DELETE /api/notifications/:id        — delete a notification
 *
 * Summary (used by nav bell badge):
 * GET    /api/me/summary               — { unreadNotificationCount, pendingFriendRequests }
 */

import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { eq, and, desc, sql, or, ne } from "drizzle-orm";
import {
  db,
  notificationsTable,
  friendRequestsTable,
} from "@workspace/db";

const router: IRouter = Router();

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId as string;
  next();
}

// GET /notifications
router.get("/notifications", requireAuth, async (req: any, res): Promise<void> => {
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.userId))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(20);

  res.json({
    notifications: notifications.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body ?? null,
      linkPath: n.linkPath ?? null,
      isRead: n.isRead,
      createdAt: n.createdAt.toISOString(),
    })),
  });
});

// PATCH /notifications/read-all — must be before /:id
router.patch(
  "/notifications/read-all",
  requireAuth,
  async (req: any, res): Promise<void> => {
    await db
      .update(notificationsTable)
      .set({ isRead: true })
      .where(
        and(
          eq(notificationsTable.userId, req.userId),
          eq(notificationsTable.isRead, false),
        ),
      );
    res.json({ ok: true });
  },
);

// DELETE /notifications/:id
router.delete(
  "/notifications/:id",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid id" });
      return;
    }

    const [notification] = await db
      .select()
      .from(notificationsTable)
      .where(eq(notificationsTable.id, id))
      .limit(1);

    if (!notification) {
      res.status(404).json({ error: "Not found" });
      return;
    }
    if (notification.userId !== req.userId) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    await db.delete(notificationsTable).where(eq(notificationsTable.id, id));
    res.json({ deleted: true });
  },
);

// GET /me/summary — nav bell badge: unread notifications + pending friend requests
router.get("/me/summary", requireAuth, async (req: any, res): Promise<void> => {
  const [[{ unreadCount }], [{ pendingCount }]] = await Promise.all([
    db
      .select({ unreadCount: sql<string>`COUNT(*)` })
      .from(notificationsTable)
      .where(
        and(
          eq(notificationsTable.userId, req.userId),
          eq(notificationsTable.isRead, false),
        ),
      ),
    db
      .select({ pendingCount: sql<string>`COUNT(*)` })
      .from(friendRequestsTable)
      .where(
        and(
          or(
            eq(friendRequestsTable.senderId, req.userId),
            eq(friendRequestsTable.receiverId, req.userId),
          ),
          ne(friendRequestsTable.initiatorId, req.userId),
          eq(friendRequestsTable.status, "pending"),
        ),
      ),
  ]);

  res.json({
    unreadNotificationCount: parseInt(unreadCount, 10) || 0,
    pendingFriendRequests: parseInt(pendingCount, 10) || 0,
  });
});

export default router;
