import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import {
  db,
  userProfilesTable,
  usernameHistoryTable,
  buildsTable,
  upgradesTable,
  buildFavoritesTable,
  followsTable,
  friendRequestsTable,
} from "@workspace/db";
import { eq, desc, isNull, and, ilike, sql, or } from "drizzle-orm";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

// ─── Helpers ──────────────────────────────────────────────────────────────────

function requireAuth(req: any, res: any, next: any): void {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

const USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;

function normalizeUsername(raw: string): string {
  return raw.toLowerCase().trim();
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}


/** Validates that a URL is safe (https: or http: scheme only). Returns the
 *  normalised URL string on success, or null if the value should be cleared.
 *  Throws a 400-grade Error if the value is non-empty but unsafe/malformed. */
function validateSocialUrl(raw: string | null | undefined, fieldName: string): string | null {
  if (!raw || raw.trim() === "") return null;
  let parsed: URL;
  try {
    parsed = new URL(raw.trim());
  } catch {
    throw Object.assign(new Error(`${fieldName}: not a valid URL`), { status: 400 });
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw Object.assign(
      new Error(`${fieldName}: only https:// and http:// URLs are allowed`),
      { status: 400 },
    );
  }
  return parsed.href;
}

function toSlug(username: string): string {
  return username.toLowerCase();
}

async function isUsernameAvailable(
  username: string,
  excludeUserId?: string,
): Promise<boolean> {
  const rows = await db
    .select({ userId: userProfilesTable.userId })
    .from(userProfilesTable)
    .where(ilike(userProfilesTable.username, username))
    .limit(1);
  if (rows.length === 0) return true;
  // Allow the current holder to "re-claim" the same name
  if (excludeUserId && rows[0].userId === excludeUserId) return true;
  return false;
}

function serializeProfile(p: typeof userProfilesTable.$inferSelect) {
  return {
    userId: p.userId,
    username: p.username,
    slug: p.slug,
    displayName: p.displayName ?? null,
    bio: p.bio ?? null,
    avatarPath: p.avatarPath ?? null,
    youtubeUrl: p.youtubeUrl ?? null,
    instagramUrl: p.instagramUrl ?? null,
    xUrl: p.xUrl ?? null,
    facebookUrl: p.facebookUrl ?? null,
    tiktokUrl: p.tiktokUrl ?? null,
    showFavoritesPublic: p.showFavoritesPublic,
    isVerified: p.isVerified,
    profileBgColor: p.profileBgColor ?? null,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

type BuildRow = {
  id: number;
  userId: string;
  authorName: string;
  gunName: string;
  category: string;
  description: string;
  totalCost: string;
  baseCost: string | null;
  specialty: string | null;
  cons: string | null;
  gunImagePath: string | null;
  createdAt: Date;
  updatedAt: Date;
  authorSlug: string | null;
  averageRating: string | null;
  ratingCount: string;
  favoriteCount: string;
  myRating: number | null;
  isFavorited: boolean;
};

/**
 * Returns engagement select fields for build queries.
 * Pass viewerId to include viewer-specific myRating and isFavorited.
 */
function engagementFields(viewerId?: string) {
  return {
    averageRating: sql<string | null>`(SELECT ROUND(AVG(br.rating)::numeric, 2) FROM build_ratings br WHERE br.build_id = ${buildsTable.id})`,
    ratingCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_ratings br WHERE br.build_id = ${buildsTable.id}), 0)`,
    favoriteCount: sql<string>`COALESCE((SELECT COUNT(*) FROM build_favorites bf WHERE bf.build_id = ${buildsTable.id}), 0)`,
    myRating: viewerId
      ? sql<number | null>`(SELECT br.rating FROM build_ratings br WHERE br.build_id = ${buildsTable.id} AND br.user_id = ${viewerId})`
      : sql<number | null>`NULL::int`,
    isFavorited: viewerId
      ? sql<boolean>`EXISTS(SELECT 1 FROM build_favorites bf WHERE bf.build_id = ${buildsTable.id} AND bf.user_id = ${viewerId})`
      : sql<boolean>`FALSE`,
  };
}

function serializeBuildPublic(b: BuildRow) {
  return {
    id: b.id,
    userId: b.userId,
    authorName: b.authorName,
    authorSlug: b.authorSlug ?? null,
    gunName: b.gunName,
    category: b.category,
    description: b.description,
    totalCost: parseFloat(b.totalCost),
    baseCost: b.baseCost != null ? parseFloat(b.baseCost) : null,
    specialty: b.specialty ?? null,
    cons: b.cons ?? null,
    gunImagePath: b.gunImagePath ?? null,
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt?.toISOString() ?? null,
    averageRating: b.averageRating != null ? parseFloat(b.averageRating) : null,
    ratingCount: parseInt(String(b.ratingCount), 10) || 0,
    favoriteCount: parseInt(String(b.favoriteCount), 10) || 0,
    myRating: b.myRating ?? null,
    isFavorited: b.isFavorited ?? false,
  };
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// GET /profiles/check-username?username=X
router.get(
  "/profiles/check-username",
  async (req, res): Promise<void> => {
    const raw = (req.query.username as string) ?? "";
    if (!USERNAME_RE.test(raw)) {
      res.json({ available: false, reason: "invalid_format" });
      return;
    }
    const normalized = normalizeUsername(raw);
    const available = await isUsernameAvailable(normalized);
    res.json({ available, reason: available ? null : "taken" });
  },
);

// GET /profiles/me
router.get("/profiles/me", requireAuth, async (req: any, res): Promise<void> => {
  const [profile] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.userId, req.userId))
    .limit(1);

  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }

  res.json(serializeProfile(profile));
});

const ALLOWED_AVATAR_CONTENT_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/avif",
] as const;

// POST /profiles/me/avatar-url  — get a user-scoped presigned upload URL for avatar
// Requires a valid image contentType in the request body so non-image uploads
// are rejected before a signed URL is issued.
router.post(
  "/profiles/me/avatar-url",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const { contentType } = req.body ?? {};
    if (
      !contentType ||
      !(ALLOWED_AVATAR_CONTENT_TYPES as ReadonlyArray<string>).includes(String(contentType))
    ) {
      res.status(400).json({
        error: `contentType must be one of: ${ALLOWED_AVATAR_CONTENT_TYPES.join(", ")}`,
      });
      return;
    }
    try {
      const { uploadURL, objectPath } = await objectStorageService.getAvatarUploadURL(req.userId);
      res.json({ uploadURL, objectPath, contentType });
    } catch {
      res.status(500).json({ error: "Failed to generate avatar upload URL" });
    }
  },
);

// POST /profiles/me/setup  — initial profile creation (first login)
router.post(
  "/profiles/me/setup",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const { username, displayName } = req.body ?? {};

    if (!username || !USERNAME_RE.test(username)) {
      res.status(400).json({
        error: "Username must be 3–30 characters: letters, numbers, underscores only",
      });
      return;
    }

    // Check if profile already exists
    const [existing] = await db
      .select({ userId: userProfilesTable.userId })
      .from(userProfilesTable)
      .where(eq(userProfilesTable.userId, req.userId))
      .limit(1);

    if (existing) {
      res.status(409).json({ error: "Profile already exists" });
      return;
    }

    const normalized = normalizeUsername(username);
    const slug = toSlug(normalized);

    const available = await isUsernameAvailable(normalized);
    if (!available) {
      res.status(409).json({ error: "Username is taken" });
      return;
    }

    const [profile] = await db
      .insert(userProfilesTable)
      .values({
        userId: req.userId,
        username: normalized,
        slug,
        displayName: displayName ?? null,
      })
      .returning();

    await db.insert(usernameHistoryTable).values({
      userId: req.userId,
      username: normalized,
      slug,
    });

    res.status(201).json(serializeProfile(profile));
  },
);

// PATCH /profiles/me  — update profile fields (not username)
router.patch(
  "/profiles/me",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const ALLOWED_SCALAR = ["displayName", "bio", "avatarPath", "showFavoritesPublic"] as const;
    const SOCIAL_URL_FIELDS = [
      "youtubeUrl",
      "instagramUrl",
      "xUrl",
      "facebookUrl",
      "tiktokUrl",
    ] as const;

    const updates: Partial<typeof userProfilesTable.$inferInsert> = {};

    for (const key of ALLOWED_SCALAR) {
      if (key in (req.body ?? {})) {
        (updates as any)[key] = req.body[key] ?? null;
      }
    }

    // Validate social link URLs — only https:// and http:// are permitted
    for (const key of SOCIAL_URL_FIELDS) {
      if (key in (req.body ?? {})) {
        try {
          (updates as any)[key] = validateSocialUrl(req.body[key], key);
        } catch (err: any) {
          res.status(err.status ?? 400).json({ error: err.message });
          return;
        }
      }
    }

    // Validate avatarPath ownership with an exact regex match.
    // The only accepted format is /objects/avatars/{safeUserId}/{uuid}
    // where safeUserId and uuid contain only alphanumeric, dash, and underscore.
    // A prefix-only check is NOT sufficient because a user could embed `..`
    // to traverse out of the avatar namespace.
    if ("avatarPath" in (req.body ?? {})) {
      const rawAvatarPath = req.body.avatarPath;
      if (rawAvatarPath == null || rawAvatarPath === "") {
        updates.avatarPath = null;
      } else {
        const safeUserId = req.userId.replace(/[^a-zA-Z0-9_-]/g, "_");
        // Exact match: /objects/avatars/{safeUserId}/{uuid}
        // No traversal (`..`), no extra segments, no encoded slashes.
        const AVATAR_PATH_EXACT = new RegExp(
          `^\\/objects\\/avatars\\/${escapeRegex(safeUserId)}\\/[a-zA-Z0-9_-]{1,128}$`,
        );
        if (!AVATAR_PATH_EXACT.test(String(rawAvatarPath))) {
          res.status(400).json({
            error:
              "avatarPath must be a path generated by your own avatar upload URL and cannot contain path traversal sequences",
          });
          return;
        }
        updates.avatarPath = String(rawAvatarPath);
      }
    }

    if (Object.keys(updates).length === 0) {
      res.status(400).json({ error: "No valid fields provided" });
      return;
    }

    const [profile] = await db
      .update(userProfilesTable)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userProfilesTable.userId, req.userId))
      .returning();

    if (!profile) {
      res.status(404).json({ error: "Profile not found" });
      return;
    }

    res.json(serializeProfile(profile));
  },
);

// POST /profiles/me/username  — change username
router.post(
  "/profiles/me/username",
  requireAuth,
  async (req: any, res): Promise<void> => {
    const { username } = req.body ?? {};

    if (!username || !USERNAME_RE.test(username)) {
      res.status(400).json({
        error: "Username must be 3–30 characters: letters, numbers, underscores only",
      });
      return;
    }

    const normalized = normalizeUsername(username);
    const slug = toSlug(normalized);

    // Check uniqueness, allowing self (no change is fine)
    const available = await isUsernameAvailable(normalized, req.userId);
    if (!available) {
      res.status(409).json({ error: "Username is taken" });
      return;
    }

    // Release old username in history
    await db
      .update(usernameHistoryTable)
      .set({ releasedAt: new Date() })
      .where(
        and(
          eq(usernameHistoryTable.userId, req.userId),
          isNull(usernameHistoryTable.releasedAt),
        ),
      );

    // Claim new username in history
    await db.insert(usernameHistoryTable).values({
      userId: req.userId,
      username: normalized,
      slug,
    });

    const [profile] = await db
      .update(userProfilesTable)
      .set({ username: normalized, slug, updatedAt: new Date() })
      .where(eq(userProfilesTable.userId, req.userId))
      .returning();

    if (!profile) {
      res.status(404).json({ error: "Profile not found" });
      return;
    }

    res.json(serializeProfile(profile));
  },
);

// GET /profiles/:slug  — public profile page
router.get("/profiles/:slug", async (req, res): Promise<void> => {
  // Optional viewer auth — builds will show myRating/isFavorited when signed in
  const auth = getAuth(req);
  const viewerId: string | undefined =
    (auth?.sessionClaims?.userId as string | undefined) ||
    (auth?.userId as string | undefined) ||
    undefined;

  const [profile] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.slug, req.params.slug))
    .limit(1);

  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }

  const builds = (await db
    .select({
      id: buildsTable.id,
      userId: buildsTable.userId,
      authorName: buildsTable.authorName,
      gunName: buildsTable.gunName,
      category: buildsTable.category,
      description: buildsTable.description,
      totalCost: buildsTable.totalCost,
      baseCost: buildsTable.baseCost,
      specialty: buildsTable.specialty,
      cons: buildsTable.cons,
      gunImagePath: buildsTable.gunImagePath,
      createdAt: buildsTable.createdAt,
      updatedAt: buildsTable.updatedAt,
      authorSlug: userProfilesTable.slug,
      ...engagementFields(viewerId),
    })
    .from(buildsTable)
    .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
    .where(eq(buildsTable.userId, profile.userId))
    .orderBy(desc(buildsTable.createdAt))) as BuildRow[];

  // Include public favorites if the user has opted in
  let publicFavorites: Array<ReturnType<typeof serializeBuildPublic> & { favoritedAt: string }> = [];
  if (profile.showFavoritesPublic) {
    const favRows = (await db
      .select({
        id: buildsTable.id,
        userId: buildsTable.userId,
        authorName: buildsTable.authorName,
        gunName: buildsTable.gunName,
        category: buildsTable.category,
        description: buildsTable.description,
        totalCost: buildsTable.totalCost,
        baseCost: buildsTable.baseCost,
        specialty: buildsTable.specialty,
        cons: buildsTable.cons,
        gunImagePath: buildsTable.gunImagePath,
        createdAt: buildsTable.createdAt,
        updatedAt: buildsTable.updatedAt,
        authorSlug: userProfilesTable.slug,
        favoritedAt: buildFavoritesTable.createdAt,
        ...engagementFields(viewerId),
      })
      .from(buildFavoritesTable)
      .innerJoin(buildsTable, eq(buildFavoritesTable.buildId, buildsTable.id))
      .leftJoin(userProfilesTable, eq(buildsTable.userId, userProfilesTable.userId))
      .where(eq(buildFavoritesTable.userId, profile.userId))
      .orderBy(desc(buildFavoritesTable.createdAt))
      .limit(12)) as (BuildRow & { favoritedAt: Date })[];

    publicFavorites = favRows.map((f) => ({
      ...serializeBuildPublic(f),
      favoritedAt: f.favoritedAt.toISOString(),
    }));
  }

  // Social counts + viewer state
  const [[{ followerCount }], [{ followingCount }], [{ friendCount }]] =
    await Promise.all([
      db
        .select({ followerCount: sql<string>`COUNT(*)` })
        .from(followsTable)
        .where(eq(followsTable.followingId, profile.userId)),
      db
        .select({ followingCount: sql<string>`COUNT(*)` })
        .from(followsTable)
        .where(eq(followsTable.followerId, profile.userId)),
      db
        .select({ friendCount: sql<string>`COUNT(*)` })
        .from(friendRequestsTable)
        .where(
          and(
            eq(friendRequestsTable.status, "accepted"),
            or(
              eq(friendRequestsTable.senderId, profile.userId),
              eq(friendRequestsTable.receiverId, profile.userId),
            ),
          ),
        ),
    ]);

  // Viewer-specific social state
  let isFollowing = false;
  let isMutual = false;
  let friendshipStatus: "none" | "pending_sent" | "pending_received" | "friends" =
    "none";
  let friendRequestId: number | null = null;

  if (viewerId && viewerId !== profile.userId) {
    const [followRow, reverseFollowRow, friendRow] = await Promise.all([
      db
        .select({ id: followsTable.id })
        .from(followsTable)
        .where(
          and(
            eq(followsTable.followerId, viewerId),
            eq(followsTable.followingId, profile.userId),
          ),
        )
        .limit(1),
      db
        .select({ id: followsTable.id })
        .from(followsTable)
        .where(
          and(
            eq(followsTable.followerId, profile.userId),
            eq(followsTable.followingId, viewerId),
          ),
        )
        .limit(1),
      // Canonical pair: always query with LEAST/GREATEST ordering
      db
        .select()
        .from(friendRequestsTable)
        .where(
          and(
            eq(
              friendRequestsTable.senderId,
              sql<string>`LEAST(${viewerId}, ${profile.userId})`,
            ),
            eq(
              friendRequestsTable.receiverId,
              sql<string>`GREATEST(${viewerId}, ${profile.userId})`,
            ),
          ),
        )
        .limit(1),
    ]);

    isFollowing = followRow.length > 0;
    isMutual = isFollowing && reverseFollowRow.length > 0;

    if (friendRow.length > 0) {
      const fr = friendRow[0];
      friendRequestId = fr.id;
      if (fr.status === "accepted") {
        friendshipStatus = "friends";
      } else if (fr.status === "pending") {
        friendshipStatus =
          fr.initiatorId === viewerId ? "pending_sent" : "pending_received";
      }
    }
  }

  res.json({
    username: profile.username,
    slug: profile.slug,
    displayName: profile.displayName ?? null,
    bio: profile.bio ?? null,
    avatarPath: profile.avatarPath ?? null,
    youtubeUrl: profile.youtubeUrl ?? null,
    instagramUrl: profile.instagramUrl ?? null,
    xUrl: profile.xUrl ?? null,
    facebookUrl: profile.facebookUrl ?? null,
    tiktokUrl: profile.tiktokUrl ?? null,
    showFavoritesPublic: profile.showFavoritesPublic,
    isVerified: profile.isVerified,
    profileBgColor: profile.profileBgColor ?? null,
    buildCount: builds.length,
    builds: builds.map(serializeBuildPublic),
    publicFavorites,
    followerCount: parseInt(followerCount, 10) || 0,
    followingCount: parseInt(followingCount, 10) || 0,
    friendCount: parseInt(friendCount, 10) || 0,
    isFollowing,
    isMutual,
    friendshipStatus,
    friendRequestId,
  });
});

export default router;
