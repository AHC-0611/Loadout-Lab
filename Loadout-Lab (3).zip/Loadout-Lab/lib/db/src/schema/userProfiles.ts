import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const userProfilesTable = pgTable("user_profiles", {
  userId: text("user_id").primaryKey(),
  username: text("username").notNull().unique(),
  slug: text("slug").notNull().unique(),
  displayName: text("display_name"),
  bio: text("bio"),
  avatarPath: text("avatar_path"),
  youtubeUrl: text("youtube_url"),
  instagramUrl: text("instagram_url"),
  xUrl: text("x_url"),
  facebookUrl: text("facebook_url"),
  tiktokUrl: text("tiktok_url"),
  showFavoritesPublic: boolean("show_favorites_public").notNull().default(false),
  isVerified: boolean("is_verified").notNull().default(false),
  profileBgColor: text("profile_bg_color"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type UserProfile = typeof userProfilesTable.$inferSelect;
