import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const usernameHistoryTable = pgTable("username_history", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  slug: text("slug").notNull(),
  claimedAt: timestamp("claimed_at", { withTimezone: true }).notNull().defaultNow(),
  releasedAt: timestamp("released_at", { withTimezone: true }),
});

export type UsernameHistory = typeof usernameHistoryTable.$inferSelect;
