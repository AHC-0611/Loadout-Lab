import { pgTable, text, serial, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { buildsTable } from "./builds";

export const upgradesTable = pgTable("upgrades", {
  id: serial("id").primaryKey(),
  buildId: integer("build_id").notNull().references(() => buildsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
  source: text("source").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertUpgradeSchema = createInsertSchema(upgradesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertUpgrade = z.infer<typeof insertUpgradeSchema>;
export type Upgrade = typeof upgradesTable.$inferSelect;
