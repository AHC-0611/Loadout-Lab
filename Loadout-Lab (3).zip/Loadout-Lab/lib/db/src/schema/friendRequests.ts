import { pgTable, serial, text, timestamp, unique, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

/**
 * Friend requests table with canonical pair ordering.
 *
 * `senderId`   — always the lexicographically SMALLER of the two user IDs
 * `receiverId` — always the lexicographically LARGER  of the two user IDs
 * `initiatorId`— the user who actually initiated the request (either party)
 *
 * Storing the pair in canonical order means `unique(sender_id, receiver_id)`
 * covers both directions, so (A→B) and (B→A) cannot coexist as separate rows.
 * The `initiatorId` carries the directional semantics without sacrificing
 * uniqueness or needing an expression index.
 */
export const friendRequestsTable = pgTable(
  "friend_requests",
  {
    id: serial("id").primaryKey(),
    /** Always LEAST(userId1, userId2) */
    senderId: text("sender_id").notNull(),
    /** Always GREATEST(userId1, userId2) */
    receiverId: text("receiver_id").notNull(),
    /** The user who actually triggered the request */
    initiatorId: text("initiator_id").notNull(),
    /** 'pending' | 'accepted' | 'declined' */
    status: text("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    unique("friend_requests_sender_receiver_unique").on(t.senderId, t.receiverId),
    check(
      "friend_requests_status_valid",
      sql`${t.status} IN ('pending', 'accepted', 'declined')`,
    ),
    // Enforce canonical ordering at DB level
    check("friend_requests_canonical_order", sql`${t.senderId} < ${t.receiverId}`),
    // Initiator must be one of the two parties
    check(
      "friend_requests_initiator_is_party",
      sql`${t.initiatorId} = ${t.senderId} OR ${t.initiatorId} = ${t.receiverId}`,
    ),
  ],
);

export type FriendRequest = typeof friendRequestsTable.$inferSelect;
