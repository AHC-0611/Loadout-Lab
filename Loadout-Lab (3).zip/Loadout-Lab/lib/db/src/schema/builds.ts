import { pgTable, text, serial, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const buildsTable = pgTable("builds", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  authorName: text("author_name").notNull(),
  gunName: text("gun_name").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  totalCost: numeric("total_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  baseCost: numeric("base_cost", { precision: 10, scale: 2 }),
  specialty: text("specialty"),
  cons: text("cons"),
  gunImagePath: text("gun_image_path"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertBuildSchema = createInsertSchema(buildsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertBuild = z.infer<typeof insertBuildSchema>;
export type Build = typeof buildsTable.$inferSelect;
