import { pgTable, serial, text, boolean, timestamp, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

/**
 * In-app notifications for users.
 * Currently used for alert matches when a new build is posted.
 */
export const notificationsTable = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    /** Notification category, e.g. 'alert_match' */
    type: text("type").notNull(),
    title: text("title").notNull(),
    body: text("body"),
    /** Frontend path to navigate to when clicked, e.g. '/builds/42' */
    linkPath: text("link_path"),
    isRead: boolean("is_read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    check("notifications_type_valid", sql`${t.type} IN ('alert_match', 'system')`),
  ],
);

export type Notification = typeof notificationsTable.$inferSelect;
