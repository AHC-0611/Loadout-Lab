import { pgTable, serial, text, timestamp, check, unique } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

/**
 * User-defined build alerts.
 * type='gun_model' matches builds.gunName (case-insensitive contains)
 * type='part'      matches any upgrades.name (case-insensitive contains)
 */
export const userAlertsTable = pgTable(
  "user_alerts",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    /** 'gun_model' | 'part' */
    type: text("type").notNull(),
    /** The keyword/phrase to watch for */
    value: text("value").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    check("user_alerts_type_valid", sql`${t.type} IN ('gun_model', 'part')`),
    unique("user_alerts_user_type_value_unique").on(t.userId, t.type, t.value),
  ],
);

export type UserAlert = typeof userAlertsTable.$inferSelect;
