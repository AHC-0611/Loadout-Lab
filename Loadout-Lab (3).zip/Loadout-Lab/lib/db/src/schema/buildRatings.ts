import { pgTable, serial, text, smallint, integer, timestamp, unique, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { buildsTable } from "./builds";

export const buildRatingsTable = pgTable(
  "build_ratings",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    buildId: integer("build_id")
      .notNull()
      .references(() => buildsTable.id, { onDelete: "cascade" }),
    rating: smallint("rating").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    unique("build_ratings_user_build_unique").on(t.userId, t.buildId),
    check("build_ratings_rating_range", sql`${t.rating} >= 1 AND ${t.rating} <= 5`),
  ],
);

export type BuildRating = typeof buildRatingsTable.$inferSelect;
