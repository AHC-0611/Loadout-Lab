import { pgTable, serial, text, integer, timestamp, unique } from "drizzle-orm/pg-core";
import { buildsTable } from "./builds";

export const buildFavoritesTable = pgTable(
  "build_favorites",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    buildId: integer("build_id")
      .notNull()
      .references(() => buildsTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("build_favorites_user_build_unique").on(t.userId, t.buildId)],
);

export type BuildFavorite = typeof buildFavoritesTable.$inferSelect;
