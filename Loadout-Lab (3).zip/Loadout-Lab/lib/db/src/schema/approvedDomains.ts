import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const approvedDomainsTable = pgTable("approved_domains", {
  id: serial("id").primaryKey(),
  domain: text("domain").notNull().unique(),
  addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
  addedBy: text("added_by").notNull(),
});

export type ApprovedDomain = typeof approvedDomainsTable.$inferSelect;
