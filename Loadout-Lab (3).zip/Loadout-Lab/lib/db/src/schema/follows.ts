import { pgTable, serial, text, timestamp, unique } from "drizzle-orm/pg-core";

export const followsTable = pgTable(
  "follows",
  {
    id: serial("id").primaryKey(),
    followerId: text("follower_id").notNull(),
    followingId: text("following_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("follows_follower_following_unique").on(t.followerId, t.followingId)],
);

export type Follow = typeof followsTable.$inferSelect;
